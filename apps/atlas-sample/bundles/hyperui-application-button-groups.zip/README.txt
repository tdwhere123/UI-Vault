分组按钮
来源：https://github.com/markmead/hyperui/blob/637323c8d3046645ac5f28edc2074d18f22a2b94/public/examples/application/button-groups/1.html
许可：MIT（见LICENSE.txt）
original.html为未改动原件，保留上游绝对资源路径。
preview.html为可直接打开的独立预览，CSS与演示脚本已内嵌，无外部请求。
component.css及component.js为本地依赖，CSS已移除Google远程字体导入。
交互范围：静态按钮外观
