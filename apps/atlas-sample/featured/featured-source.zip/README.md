# Four featured materials

preview/ contains a completely local build; serve it with a static HTTP server. build/ contains the actual transitive source files, adapters, package-lock and Vite config. Run npm ci then npx vite build --config vite.vault.config.ts (Node 24). No node_modules are bundled.

originals/ preserves upstream source separately. All registry theme/keyframes are retained in the adapter CSS. Magic UI center content and orbit glyphs are our demo composition, not upstream branding.

Looseleaf code/art/Kevin Sans: MIT. IBM Plex Mono: SIL OFL 1.1. npm component licenses included under licenses/npm.
