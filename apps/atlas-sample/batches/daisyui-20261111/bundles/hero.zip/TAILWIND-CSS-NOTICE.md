# Tailwind CSS v4.3.3 notice for this download package

This file binds the official Tailwind CSS v4.3.3 MIT license to the `runtime.css` member actually stored in this ZIP.

- Item id: `daisyui:hero`
- ZIP path: `batches/daisyui-20261111/bundles/hero.zip`
- `runtime.css` SHA-256: `d05b5c0fe8e8a71d3f91c3b60a733cf45d964156b44f2416b9d32d8d79b79927` (133360 bytes)
- Official license text member in this ZIP: `licenses/tailwindcss-v4.3.3/LICENSE.txt`
- That member is byte-identical to the tree authority `apps/atlas-sample/licenses/tailwindcss-v4.3.3/LICENSE.txt`
- Authority / official text SHA-256: `60e0b68c0f35c078eef3a5d29419d0b03ff84ec1df9c3f9d6e39a519a5ae7985` (1071 bytes)
- Official source (already retrieved; this packer does not fetch the network): https://raw.githubusercontent.com/tailwindlabs/tailwindcss/v4.3.3/LICENSE
- Copyright (c) Tailwind Labs, Inc.
- The full MIT permission notice is in the LICENSE member named above. This notice does not replace that text. The existing CSS banner `/*! tailwindcss v4.3.3 | MIT License | https://tailwindcss.com */` is retained unchanged.

This CSS is compiler output of Tailwind CSS v4.3.3. The compiler is a build tool, not a runtime JavaScript dependency of this package. This package's `runtime.css` includes `@layer base` / preflight-derived base rules as actually distributed bytes; this notice covers that distributed CSS. No modern-normalize version is guessed or added.

This notice does not license or close any other third-party code in this package, including any Popper or other implementations in `runtime.js`, and including Chart.js, images, logos, or other assets where present. Those remain separate gaps where they exist.
