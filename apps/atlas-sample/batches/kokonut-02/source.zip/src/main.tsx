import React from "react";import {createRoot} from "react-dom/client";import "./styles.css";
import C0 from "./components/activity-terrain.tsx";
import C1 from "./components/seat-map.tsx";
import C2 from "./components/ai-agent-lanes.tsx";
import C3 from "./components/synced-transcript.tsx";
import C4 from "./components/spending-ring.tsx";
import C5 from "./components/status-island.tsx";
const demos={"activity-terrain": C0,"seat-map": C1,"ai-agent-lanes": C2,"synced-transcript": C3,"spending-ring": C4,"status-island": C5};
const name=document.body.dataset.demo;const Demo=demos[name];if(!Demo)throw Error("Unknown demo: "+name);createRoot(document.getElementById("root")).render(<div className="demo-stage"><Demo/></div>);
