import React from "react";import {createRoot} from "react-dom/client";import "./styles.css";
import Demo from "./components/smooth-tab.tsx";
createRoot(document.getElementById("root")).render(<div className="demo-stage"><Demo/></div>);
