import React from 'react';import{createRoot}from'react-dom/client';import './styles.css';
import {GlowEffectCardMode as C0} from './demos/glow-effect/glow-effect-card-mode.tsx';
import {BorderTrailCard2 as C1} from './demos/border-trail/border-trail-card-2.tsx';
import {SpotlightBorder as C2} from './demos/spotlight/spotlight-border.tsx';
import {TiltSpotlight as C3} from './demos/tilt/tilt-spotlight.tsx';
import {AppleStyleDock as C4} from './demos/dock/apple-style-dock.tsx';
import {MorphingDialogBasicOne as C5} from './demos/morphing-dialog/morphing-dialog-basic-1.tsx';
const components={'glow-effect':C0,'border-trail':C1,'spotlight':C2,'tilt':C3,'dock':C4,'morphing-dialog':C5};
const el=document.getElementById('root');const Demo=components[el.dataset.demo];createRoot(el).render(<div className='vault-stage'><Demo/></div>);