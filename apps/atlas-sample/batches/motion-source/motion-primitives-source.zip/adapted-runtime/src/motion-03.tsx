import React from 'react';import{createRoot}from'react-dom/client';import './styles.css';
import {TextEffectWithPreset as C0} from './demos/text-effect/text-effect-preset.tsx';
import {TextLoopCustomVariantsTransition as C1} from './demos/text-loop/text-loop-custom-variants-transition.tsx';
import {TextMorphButton as C2} from './demos/text-morph/text-morph-button.tsx';
import {TextRollCustomVariants as C3} from './demos/text-roll/text-roll-custom-variants.tsx';
import {TextScrambleCustomTrigger as C4} from './demos/text-scramble/text-scramble-custom-trigger.tsx';
import {TextShimmerWaveColor as C5} from './demos/text-shimmer-wave/text-shimmer-wave-color.tsx';
const components={'text-effect':C0,'text-loop':C1,'text-morph':C2,'text-roll':C3,'text-scramble':C4,'text-shimmer-wave':C5};
const el=document.getElementById('root');const Demo=components[el.dataset.demo];createRoot(el).render(<div className='vault-stage'><Demo/></div>);