import { Cursor } from '@/components/core/cursor';

export function Cursor3() {
  return (
    <div>
      <div className='p-4'>
        <Cursor
          attachToParent
          variants={{
            initial: { height: 0, opacity: 0, scale: 0.3 },
            animate: { height: 'auto', opacity: 1, scale: 1 },
            exit: { height: 0, opacity: 0, scale: 0.3 },
          }}
          transition={{
            type: 'spring',
            duration: 0.3,
            bounce: 0.1,
          }}
          className='overflow-hidden'
          springConfig={{
            bounce: 0.01,
          }}
        >
          <img
            src='data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4MDAiIGhlaWdodD0iNjAwIiB2aWV3Qm94PSIwIDAgODAwIDYwMCI+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJnIiB4Mj0iMSIgeTI9IjEiPjxzdG9wIHN0b3AtY29sb3I9IiMyNDIzNGQiLz48c3RvcCBvZmZzZXQ9Ii41IiBzdG9wLWNvbG9yPSIjNzg3OWRkIi8+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjZWRjN2I3Ii8+PC9saW5lYXJHcmFkaWVudD48L2RlZnM+PHJlY3Qgd2lkdGg9IjgwMCIgaGVpZ2h0PSI2MDAiIGZpbGw9InVybCgjZykiLz48Y2lyY2xlIGN4PSI1NzAiIGN5PSIxNzAiIHI9IjEzMCIgZmlsbD0iI2Y4ZTZjZSIvPjxwYXRoIGQ9Ik0wIDQ0MFEyMzAgMTYwIDQzMCA0MjBUODAwIDMxMFY2MDBIMCIgZmlsbD0iIzI3MmY2MCIvPjxwYXRoIGQ9Ik0wIDUyMFEzMjAgMzAwIDgwMCA0OTBWNjAwSDAiIGZpbGw9IiMxYjI0NDMiLz48L3N2Zz4='
            alt='Christian Church, Eastern Europe'
            className='h-40 w-40'
          />
        </Cursor>
        Christian Church, Eastern Europe
      </div>
    </div>
  );
}
