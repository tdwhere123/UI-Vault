import { SVGProps } from 'react';
import { Cursor } from '@/components/core/cursor';

const MouseIcon = (props: SVGProps<SVGSVGElement>) => {
  return (
    <svg
      xmlns='http://www.w3.org/2000/svg'
      width={26}
      height={31}
      fill='none'
      {...props}
    >
      <g clipPath='url(#a)'>
        <path
          fill={'#22c55e'}
          fillRule='evenodd'
          stroke={'#fff'}
          strokeLinecap='square'
          strokeWidth={2}
          d='M21.993 14.425 2.549 2.935l4.444 23.108 4.653-10.002z'
          clipRule='evenodd'
        />
      </g>
      <defs>
        <clipPath id='a'>
          <path fill={'#22c55e'} d='M0 0h26v31H0z' />
        </clipPath>
      </defs>
    </svg>
  );
};

export function Cursor2() {
  return (
    <div className='py-12'>
      <div className='overflow-hidden rounded-[12px] bg-white p-2 shadow-md dark:bg-black'>
        <Cursor
          attachToParent
          variants={{
            initial: { scale: 0.3, opacity: 0 },
            animate: { scale: 1, opacity: 1 },
            exit: { scale: 0.3, opacity: 0 },
          }}
          transition={{
            ease: 'easeInOut',
            duration: 0.15,
          }}
          className='left-12 top-4'
        >
          <div>
            <MouseIcon className='h-6 w-6' />
            <div className='ml-4 mt-1 rounded-[4px] bg-green-500 px-2 py-0.5 text-neutral-50'>
              The city below
            </div>
          </div>
        </Cursor>
        <img
          src='data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4MDAiIGhlaWdodD0iNjAwIiB2aWV3Qm94PSIwIDAgODAwIDYwMCI+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJnIiB4Mj0iMSIgeTI9IjEiPjxzdG9wIHN0b3AtY29sb3I9IiMyNDIzNGQiLz48c3RvcCBvZmZzZXQ9Ii41IiBzdG9wLWNvbG9yPSIjNzg3OWRkIi8+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjZWRjN2I3Ii8+PC9saW5lYXJHcmFkaWVudD48L2RlZnM+PHJlY3Qgd2lkdGg9IjgwMCIgaGVpZ2h0PSI2MDAiIGZpbGw9InVybCgjZykiLz48Y2lyY2xlIGN4PSI1NzAiIGN5PSIxNzAiIHI9IjEzMCIgZmlsbD0iI2Y4ZTZjZSIvPjxwYXRoIGQ9Ik0wIDQ0MFEyMzAgMTYwIDQzMCA0MjBUODAwIDMxMFY2MDBIMCIgZmlsbD0iIzI3MmY2MCIvPjxwYXRoIGQ9Ik0wIDUyMFEzMjAgMzAwIDgwMCA0OTBWNjAwSDAiIGZpbGw9IiMxYjI0NDMiLz48L3N2Zz4='
          alt='Green herbs'
          className='h-40 w-full max-w-32 rounded-[8px] object-cover'
        />
      </div>
    </div>
  );
}
