import React from 'react';import{createRoot}from'react-dom/client';import './styles.css';
import {MorphingPopoverTextarea as C0} from './demos/morphing-popover/morphing-popover-textarea.tsx';
import {ImageComparisonSpring as C1} from './demos/image-comparison/image-comparison-spring.tsx';
import {ProgressiveBlurHover as C2} from './demos/progressive-blur/progressive-blur-hover.tsx';
import {InfiniteSliderHoverSpeed as C3} from './demos/infinite-slider/infinite-slider-hover-speed.tsx';
import {CarouselCustomSizes as C4} from './demos/carousel/carousel-custom-sizes.tsx';
import {MagneticNested as C5} from './demos/magnetic/magnetic-nested.tsx';
const components={'morphing-popover':C0,'image-comparison':C1,'progressive-blur':C2,'infinite-slider':C3,'carousel':C4,'magnetic':C5};
const el=document.getElementById('root');const Demo=components[el.dataset.demo];createRoot(el).render(<div className='vault-stage'><Demo/></div>);