import React from 'react';import{createRoot}from'react-dom/client';import './styles.css';
import {TransitionPanelCard as C0} from './demos/transition-panel/transition-panel-card.tsx';
import {AnimatedGroupCustomVariants2 as C1} from './demos/animated-group/animated-group-custom-variants-2.tsx';
import {AnimatedNumberCounter as C2} from './demos/animated-number/animated-number-counter.tsx';
import {Cursor3 as C3} from './demos/cursor/cursor-3.tsx';
import {InViewImagesGrid as C4} from './demos/in-view/in-view-images-grid.tsx';
import {ScrollProgressBasic2 as C5} from './demos/scroll-progress/scroll-progress-basic-2.tsx';
const components={'transition-panel':C0,'animated-group':C1,'animated-number':C2,'cursor':C3,'in-view':C4,'scroll-progress':C5};
const el=document.getElementById('root');const Demo=components[el.dataset.demo];createRoot(el).render(<div className='vault-stage'><Demo/></div>);