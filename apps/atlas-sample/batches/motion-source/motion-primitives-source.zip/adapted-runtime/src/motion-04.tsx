import React from 'react';import{createRoot}from'react-dom/client';import './styles.css';
import {TextShimmerColor as C0} from './demos/text-shimmer/text-shimmer-color.tsx';
import {SpinningTextCustomVariants as C1} from './demos/spinning-text/spinning-text-custom-variants.tsx';
import {Clock as C2} from './demos/sliding-number/clock.tsx';
import {AnimatedCardBackgroundHover as C3} from './demos/animated-background/animated-card-background-hover.tsx';
import C4 from './components/core/toolbar-dynamic.tsx';
import C5 from './components/core/toolbar-expandable.tsx';
const components={'text-shimmer':C0,'spinning-text':C1,'sliding-number':C2,'animated-background':C3,'toolbar-dynamic':C4,'toolbar-expandable':C5};
const el=document.getElementById('root');const Demo=components[el.dataset.demo];createRoot(el).render(<div className='vault-stage'><Demo/></div>);