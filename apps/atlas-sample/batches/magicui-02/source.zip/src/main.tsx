import * as React from 'react';import {createRoot} from 'react-dom/client';import './styles.css';
import Demo0 from './demos/text-3d-flip';
import Demo1 from './demos/morphing-text';
import Demo2 from './demos/terminal';
import Demo3 from './demos/border-beam';
import Demo4 from './demos/sparkles-text';
const demos={'text-3d-flip':Demo0,'morphing-text':Demo1,'terminal':Demo2,'border-beam':Demo3,'sparkles-text':Demo4};const root=document.getElementById('root')!;const Demo=demos[root.dataset.demo as keyof typeof demos];createRoot(root).render(<div className={'stage stage-'+root.dataset.demo}><Demo/></div>);