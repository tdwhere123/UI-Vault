// Normalize the upstream CJS default export without changing its renderer.
import moduleValue from 'ansi-to-react/lib/index.js';
const raw:any=moduleValue;
const Ansi = typeof raw === 'function' ? raw : raw.default;
export default Ansi;
