管理看板整页
来源：https://github.com/creativetimofficial/notus-js/blob/e3ca2299dd2caab1ef37b420d2209c3b9c3fca5e/pages/admin/dashboard.html
许可：MIT（见LICENSE.txt）；Font Awesome Free、Popper 与 Chart.js 2.9.3 许可在源码包内。
Font Awesome 的 woff2 已按相对路径保存在 fonts/，并在 runtime.css 中以 data-uri 嵌入以适配现有 font-src data 策略。
落地页中的 Unsplash 远程图仍用占位，未保存那些原图。
交互范围：浏览管理看板并查看本地图表（已内置 Chart.js 与 Popper；人像为仓库原件本地副本）
未做真实浏览器视觉与交互验收，也没有真实封面。跳过了依赖 Google Maps API 密钥的地图页。
