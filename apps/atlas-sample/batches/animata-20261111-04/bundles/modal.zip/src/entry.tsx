import React from "react";
import {createRoot} from "react-dom/client";
import * as S from "./animata/overlay/modal.stories";
const meta = S.default;
const story = S.Primary || (Object.entries(S).find(([k, v]) => k !== "default" && v && typeof v === "object") || [])[1];
const args = {...(meta && meta.args), ...(story && story.args)};
const Comp = meta.component;
createRoot(document.getElementById("root")).render(story && story.render ? story.render(args) : <Comp {...args}/>);
