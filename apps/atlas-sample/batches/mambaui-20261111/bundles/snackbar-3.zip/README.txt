带操作提示条（mambaui:snackbar-3）
来源：Mamba UI @ de03932581585acb38adb6039ce2cae7e57cd619
原件：Angular 模板。预览已静态解析主题类并拦截链接/表单，不表示源交互或后端已验收。
