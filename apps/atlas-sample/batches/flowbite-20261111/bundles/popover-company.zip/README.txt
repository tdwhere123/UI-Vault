公司资料弹出层
来源：https://github.com/themesberg/flowbite/blob/232ebdb33a9e37b31b293b9988d89b862ee121e5/content/components/popover.md
许可：MIT（见LICENSE.txt）
official assets/ 下为官方仓库原图或标识的本地副本。
preview.html 配合同目录 runtime.css、runtime.js 与 assets/ 本地打开。
仍有无授权远程图以占位替换，未保存那些原图。
交互范围：查看公司资料弹出层（已内置本地交互脚本，远程标识已换占位图）（部分图为官方仓库本地副本，其余仍为占位）
预览中的拦截脚本或内置库是本线加入的本地适配，不表示源交互已验证。未做真实浏览器视觉与交互验收，也没有真实运行页面封面。
