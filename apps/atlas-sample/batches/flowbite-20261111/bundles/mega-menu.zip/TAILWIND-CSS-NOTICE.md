# Tailwind CSS v4.3.3 notice for this download package

This file binds the official Tailwind CSS v4.3.3 MIT license to the `runtime.css` member actually stored in this ZIP.

- Item id: `flowbite:mega-menu`
- ZIP path: `batches/flowbite-20261111/bundles/mega-menu.zip`
- `runtime.css` SHA-256: `4565be2988b00093e432de0a16a8a203a51ff5cd0ebe9099111a56fc3ee5d981` (40753 bytes)
- Official license text member in this ZIP: `licenses/tailwindcss-v4.3.3/LICENSE.txt`
- That member is byte-identical to the tree authority `apps/atlas-sample/licenses/tailwindcss-v4.3.3/LICENSE.txt`
- Authority / official text SHA-256: `60e0b68c0f35c078eef3a5d29419d0b03ff84ec1df9c3f9d6e39a519a5ae7985` (1071 bytes)
- Official source (already retrieved; this packer does not fetch the network): https://raw.githubusercontent.com/tailwindlabs/tailwindcss/v4.3.3/LICENSE
- Copyright (c) Tailwind Labs, Inc.
- The full MIT permission notice is in the LICENSE member named above. This notice does not replace that text. The existing CSS banner `/*! tailwindcss v4.3.3 | MIT License | https://tailwindcss.com */` is retained unchanged.

This CSS is compiler output of Tailwind CSS v4.3.3. The compiler is a build tool, not a runtime JavaScript dependency of this package. This package's `runtime.css` includes `@layer base` / preflight-derived base rules as actually distributed bytes; this notice covers that distributed CSS. No modern-normalize version is guessed or added.

This notice does not license or close any other third-party code in this package, including any Popper or other implementations in `runtime.js`. Those remain separate gaps where they exist.

This ZIP's `runtime.css` SHA-256 differs from the current production preview file `batches/flowbite-20261111/runtime.css` SHA-256 `0c5effb39a6f8107f1d190c902b93b21b61d98bf9872c52f8b59d2c448e17047`. This task does not change CSS bytes or synchronize them.
