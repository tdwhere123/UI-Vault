import {useState} from "react";
"use client";

import {
  PackageInfo,
  PackageInfoChangeType,
  PackageInfoContent,
  PackageInfoDependencies,
  PackageInfoDependency,
  PackageInfoDescription,
  PackageInfoHeader,
  PackageInfoName,
  PackageInfoVersion,
} from "@repo/elements/package-info";

const Example = () => {const[accepted,setAccepted]=useState(false);return (
  <div className="flex flex-col gap-4"><button className="rounded border px-3 py-2 text-sm" onClick={()=>setAccepted(v=>!v)}>{accepted?"Change marked for review · Reset":"Mark this dependency proposal for review"}</button>
    <PackageInfo
      changeType="major"
      currentVersion="18.2.0"
      name="react"
      newVersion="19.0.0"
    >
      <PackageInfoHeader>
        <PackageInfoName />
        <PackageInfoChangeType />
      </PackageInfoHeader>
      <PackageInfoVersion />
      <PackageInfoDescription>
        A JavaScript library for building user interfaces.
      </PackageInfoDescription>
      <PackageInfoContent>
        <PackageInfoDependencies>
          <PackageInfoDependency name="react-dom" version="^19.0.0" />
          <PackageInfoDependency name="scheduler" version="^0.24.0" />
        </PackageInfoDependencies>
      </PackageInfoContent>
    </PackageInfo>

    <PackageInfo changeType="added" name="lodash">
      <PackageInfoHeader>
        <PackageInfoName />
        <PackageInfoChangeType />
      </PackageInfoHeader>
      <PackageInfoVersion />
    </PackageInfo>

    <PackageInfo changeType="removed" currentVersion="2.29.4" name="moment" />
  </div>
);};

export default Example;
