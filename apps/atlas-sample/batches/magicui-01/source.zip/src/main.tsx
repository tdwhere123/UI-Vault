import * as React from 'react';import {createRoot} from 'react-dom/client';import './styles.css';
import Demo0 from './demos/neon-gradient-card';
import Demo1 from './demos/animated-beam';
import Demo2 from './demos/glyph-matrix';
import Demo3 from './demos/dither-field';
import Demo4 from './demos/floating-3d-particles';
const demos={'neon-gradient-card':Demo0,'animated-beam':Demo1,'glyph-matrix':Demo2,'dither-field':Demo3,'floating-3d-particles':Demo4};const root=document.getElementById('root')!;const Demo=demos[root.dataset.demo as keyof typeof demos];createRoot(root).render(<div className={'stage stage-'+root.dataset.demo}><Demo/></div>);