import * as esbuild from "esbuild";
import { readFileSync, writeFileSync } from "node:fs";

const svgAsNextImage = {
  name: "svg-as-src",
  setup(build) {
    build.onLoad({ filter: /\.svg$/ }, (args) => {
      const url = "data:image/svg+xml;base64," + readFileSync(args.path).toString("base64");
      return { contents: "export default { src: " + JSON.stringify(url) + " };", loader: "js" };
    });
  },
};

const result = await esbuild.build({
  absWorkingDir: new URL(".", import.meta.url).pathname,
  entryPoints: ["src/entry.tsx"],
  bundle: true,
  minify: true,
  format: "iife",
  outfile: "runtime.js",
  jsx: "automatic",
  platform: "browser",
  target: "es2022",
  loader: { ".tsx": "tsx", ".ts": "ts", ".css": "css" },
  plugins: [svgAsNextImage],
  logLevel: "info",
  metafile: true,
});
writeFileSync("metafile.json", JSON.stringify(result.metafile, null, 2) + "\n");
