# Third-party licenses

Bundle notices and compile-graph notices are listed separately.
A package listed in metafile `inputs` was read during compile; only packages with
`outputs[runtime.js|runtime.css].inputs.bytesInOutput > 0` were actually emitted into the distributed runtime.
Identical notice bytes are stored once; every rights holder and package version is listed.
Originals of the official Mantine example are unchanged and remain under the root MIT licence in LICENSE.txt.

## Packages emitted in this runtime (bytesInOutput > 0)

- `@floating-ui/core@1.8.0` — 9417 JS bytes, 0 CSS bytes
- `@floating-ui/dom@1.8.0` — 7154 JS bytes, 0 CSS bytes
- `@floating-ui/react@0.27.20` — 12026 JS bytes, 0 CSS bytes
- `@floating-ui/react-dom@2.1.9` — 3276 JS bytes, 0 CSS bytes
- `@floating-ui/utils@0.2.12` — 3888 JS bytes, 0 CSS bytes
- `@mantine/core@9.7.3` — 134135 JS bytes, 251854 CSS bytes
- `@mantine/hooks@9.7.3` — 12889 JS bytes, 0 CSS bytes
- `@mantinex/mantine-logo@2.0.0` — 9216 JS bytes, 0 CSS bytes
- `@tabler/icons-react@3.40.0` — 880 JS bytes, 0 CSS bytes
- `clsx@2.1.1` — 372 JS bytes, 0 CSS bytes
- `get-nonce@1.0.1` — 99 JS bytes, 0 CSS bytes
- `react@19.3.1` — 8433 JS bytes, 0 CSS bytes
- `react-dom@19.3.1` — 209683 JS bytes, 0 CSS bytes
- `react-remove-scroll@2.7.2` — 5951 JS bytes, 0 CSS bytes
- `react-remove-scroll-bar@2.3.8` — 2229 JS bytes, 0 CSS bytes
- `react-style-singleton@2.2.3` — 747 JS bytes, 0 CSS bytes
- `scheduler@0.28.0` — 3713 JS bytes, 0 CSS bytes
- `tslib@2.3.1` — 1296 JS bytes, 0 CSS bytes
- `use-callback-ref@1.3.3` — 670 JS bytes, 0 CSS bytes
- `use-sidecar@1.1.3` — 1170 JS bytes, 0 CSS bytes

## Rights holders for emitted packages

- Copyright (c) 2021-present Floating UI contributors — @floating-ui/core@1.8.0
- Copyright (c) 2021-present Floating UI contributors — @floating-ui/dom@1.8.0
- Copyright (c) 2021-present Floating UI contributors — @floating-ui/react@0.27.20
- Copyright (c) 2021-present Floating UI contributors — @floating-ui/react-dom@2.1.9
- Copyright (c) 2021-present Floating UI contributors — @floating-ui/utils@0.2.12
- Copyright (c) 2021 Vitaly Rtishchev — @mantine/core@9.7.3
- Copyright (c) 2021 Vitaly Rtishchev — @mantine/hooks@9.7.3
- Copyright (c) 2021 Vitaly Rtishchev — @mantinex/mantine-logo@2.0.0
- Copyright (c) 2020-2026 Paweł Kuna — @tabler/icons-react@3.40.0
- Copyright (c) Luke Edwards <luke.edwards05@gmail.com> (lukeed.com) — clsx@2.1.1
- Copyright (c) 2020 Anton Korzunov — get-nonce@1.0.1
- Copyright (c) Meta Platforms, Inc. and affiliates. — react@19.3.1
- Copyright (c) Meta Platforms, Inc. and affiliates. — react-dom@19.3.1
- Copyright (c) 2017 Anton Korzunov — react-remove-scroll@2.7.2
- Copyright (c) 2025 Anton Korzunov <thekashey@gmail.com> — react-remove-scroll-bar@2.3.8
- Copyright (c) 2017 Anton Korzunov — react-style-singleton@2.2.3
- Copyright (c) Meta Platforms, Inc. and affiliates. — scheduler@0.28.0
- Copyright (c) Microsoft Corporation. — tslib@2.3.1
- Copyright (c) 2017 Anton Korzunov — use-callback-ref@1.3.3
- Copyright (c) 2017 Anton Korzunov — use-sidecar@1.1.3

## Notices for emitted packages

### Notice 1
Used by: @floating-ui/core@1.8.0, @floating-ui/dom@1.8.0, @floating-ui/react@0.27.20, @floating-ui/react-dom@2.1.9, @floating-ui/utils@0.2.12
Rights holders in this notice: Copyright (c) 2021-present Floating UI contributors

MIT License

Copyright (c) 2021-present Floating UI contributors

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

### Notice 2
Used by: tslib@2.3.1
Rights holders in this notice: Copyright (c) Microsoft Corporation.

Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.

### Notice 3
Used by: react-remove-scroll@2.7.2, react-style-singleton@2.2.3, use-callback-ref@1.3.3, use-sidecar@1.1.3
Rights holders in this notice: Copyright (c) 2017 Anton Korzunov

MIT License

Copyright (c) 2017 Anton Korzunov

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

### Notice 4
Used by: @mantine/core@9.7.3, @mantine/hooks@9.7.3, @mantinex/mantine-logo@2.0.0
Rights holders in this notice: Copyright (c) 2021 Vitaly Rtishchev

MIT License

Copyright (c) 2021 Vitaly Rtishchev

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

### Notice 5
Used by: clsx@2.1.1
Rights holders in this notice: Copyright (c) Luke Edwards <luke.edwards05@gmail.com> (lukeed.com)

MIT License

Copyright (c) Luke Edwards <luke.edwards05@gmail.com> (lukeed.com)

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

### Notice 6
Used by: react-remove-scroll-bar@2.3.8
Rights holders in this notice: Copyright (c) 2025 Anton Korzunov <thekashey@gmail.com>

MIT License

Copyright (c) 2025 Anton Korzunov <thekashey@gmail.com>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

### Notice 7
Used by: get-nonce@1.0.1
Rights holders in this notice: Copyright (c) 2020 Anton Korzunov

MIT License

Copyright (c) 2020 Anton Korzunov

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

### Notice 8
Used by: @tabler/icons-react@3.40.0
Rights holders in this notice: Copyright (c) 2020-2026 Paweł Kuna

MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

### Notice 9
Used by: react@19.3.1, react-dom@19.3.1, scheduler@0.28.0
Rights holders in this notice: Copyright (c) Meta Platforms, Inc. and affiliates.

MIT License

Copyright (c) Meta Platforms, Inc. and affiliates.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Compile-graph packages read but not emitted

These packages appear in the esbuild metafile inputs of this item, so they were part of the
compile/recipe graph, but they contributed 0 bytes to runtime.js / runtime.css.
They are not distributed in this bundle. Notices are recorded here so the recipe graph is not silent.

- `detect-node-es@1.1.0` — read during compile, bytesInOutput=0
- `react-number-format@5.4.5` — read during compile, bytesInOutput=0
- `tabbable@6.2.0` — read during compile, bytesInOutput=0
- Copyright (c) 2017 Ilya Kantor — detect-node-es@1.1.0
- Copyright (c) 2020-present Sudhanshu Yadav — react-number-format@5.4.5
- Copyright (c) 2015 David Clark — tabbable@6.2.0

## Notices for read-but-not-emitted packages

### Notice 1
Used by: detect-node-es@1.1.0
Rights holders in this notice: Copyright (c) 2017 Ilya Kantor

MIT License

Copyright (c) 2017 Ilya Kantor

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

### Notice 2
Used by: react-number-format@5.4.5
Rights holders in this notice: Copyright (c) 2020-present Sudhanshu Yadav

MIT License

Copyright (c) 2020-present Sudhanshu Yadav

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

### Notice 3
Used by: tabbable@6.2.0
Rights holders in this notice: Copyright (c) 2015 David Clark

The MIT License (MIT)

Copyright (c) 2015 David Clark

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Build tool (esbuild, not part of the browser runtime)

- `esbuild@0.28.2`

MIT License

Copyright (c) 2020 Evan Wallace

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

