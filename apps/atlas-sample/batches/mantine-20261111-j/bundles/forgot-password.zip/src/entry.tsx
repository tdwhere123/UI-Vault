import { createRoot } from "react-dom/client";
import { MantineProvider, createTheme } from "@mantine/core";
import { ForgotPassword } from "./official/ForgotPassword";
import "@mantine/core/styles.css";
import "./official/ForgotPassword.module.css";

const theme = createTheme({
  fontFamily: "system-ui, -apple-system, Segoe UI, sans-serif",
});

const memoryColorSchemeManager = {
  get(defaultValue) { return defaultValue; },
  set() {},
  subscribe() {},
  unsubscribe() {},
  clear() {},
};

createRoot(document.getElementById("root")).render(
  <MantineProvider
    theme={theme}
    defaultColorScheme="light"
    forceColorScheme="light"
    colorSchemeManager={memoryColorSchemeManager}
  >
    <div style={{ padding: 24, maxWidth: 1100, margin: "0 auto" }}>
      <ForgotPassword />
    </div>
  </MantineProvider>
);
