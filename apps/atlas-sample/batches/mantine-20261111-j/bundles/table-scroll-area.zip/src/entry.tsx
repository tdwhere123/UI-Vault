import { createRoot } from "react-dom/client";
import { MantineProvider, createTheme } from "@mantine/core";
import { TableScrollArea } from "./official/TableScrollArea";
import "@mantine/core/styles.css";
import "./official/TableScrollArea.module.css";

const theme = createTheme({
  fontFamily: "system-ui, -apple-system, Segoe UI, sans-serif",
});

const memoryColorSchemeManager = {
  get(defaultValue) { return defaultValue; },
  set() {},
  subscribe() {},
  unsubscribe() {},
  clear() {},
};

createRoot(document.getElementById("root")).render(
  <MantineProvider
    theme={theme}
    defaultColorScheme="light"
    forceColorScheme="light"
    colorSchemeManager={memoryColorSchemeManager}
  >
    <div style={{ padding: 24, maxWidth: 1100, margin: "0 auto" }}>
      <TableScrollArea />
    </div>
  </MantineProvider>
);
