404找不到页面
来源：https://github.com/merakiui/merakiui/blob/fe0472efe93f6cd275424ecbdfa7f6cb8da6f908/components/404-pages/Centered.html
许可：MIT（见LICENSE.txt）
original.html为未改动原件。
preview.html配合同目录runtime.css与runtime.js本地打开；CSS已编译，无CDN。
交互范围：阅读空页说明（演示链接已拦截）
未做真实浏览器视觉与交互验收，也没有真实运行页面封面。
