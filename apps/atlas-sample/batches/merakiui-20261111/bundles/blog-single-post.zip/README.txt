博文阅读页
来源：https://github.com/merakiui/merakiui/blob/fe0472efe93f6cd275424ecbdfa7f6cb8da6f908/components/blog/SinglePost.html
许可：MIT（见LICENSE.txt）
original.html为未改动原件。
preview.html配合同目录runtime.css与runtime.js本地打开；CSS已编译，无CDN。
预览中有2处远程图片或标识已替换为本地原创占位图，不把远程素材当作已授权收录。
交互范围：阅读单篇博文（远程照片已换成本地占位图）
未做真实浏览器视觉与交互验收，也没有真实运行页面封面。
