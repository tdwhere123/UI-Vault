#!/usr/bin/env python3
"""Build complete Iconify series into offline teaching galleries. Python standard library only."""
from pathlib import Path
import argparse,json,re,shutil,hashlib,zipfile,xml.etree.ElementTree as ET,html
HERE=Path(__file__).resolve().parent
TAGS={'svg','g','path','circle','rect','ellipse','line','polyline','polygon','defs','use','clipPath','mask','linearGradient','radialGradient','stop','title','desc'}
ATTRS=set('class d fill fill-rule fill-opacity stroke stroke-width stroke-linecap stroke-linejoin stroke-miterlimit stroke-dasharray stroke-dashoffset stroke-opacity opacity transform cx cy r rx ry x y x1 y1 x2 y2 width height points viewBox preserveAspectRatio id href clip-path clip-rule mask maskUnits maskContentUnits gradientUnits gradientTransform offset stop-color stop-opacity vector-effect color'.split())
def safe_body(body):
 if '<!DOCTYPE' in body.upper() or '<!ENTITY' in body.upper():raise ValueError('XML declarations are not allowed')
 root=ET.fromstring('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">'+body+'</svg>')
 for node in root.iter():
  node.tag=node.tag.split('}')[-1]
  if node.tag not in TAGS:raise ValueError('Unsupported SVG element '+node.tag)
  attrs={}
  for k,v in node.attrib.items():
   k=k.split('}')[-1]
   if k not in ATTRS or k.lower().startswith('on'):raise ValueError('Unsupported SVG attribute '+k)
   if re.search(r'javascript:|data:|https?:|expression\(',v,re.I):raise ValueError('External or executable SVG attribute')
   if k=='href' and not re.fullmatch(r'#[\w.:-]+',v):raise ValueError('Only local SVG references allowed')
   if 'url(' in v and not re.fullmatch(r'url\(#[\w.:-]+\)',v):raise ValueError('Only local SVG references allowed')
   attrs[k]=v
  node.attrib=attrs
 return body  # validated vector bytes preserved, not reserialized
def variant(name,prefix):
 if prefix=='ph':
  for v in ['bold','duotone','fill','light','thin']:
   if name.endswith('-'+v):return v,v.capitalize()
  return 'regular','Regular / Stroke'
 if prefix in ['tabler','heroicons','bi']:
  if re.search(r'-(fill|filled|solid)$',name):return 'fill','Fill / Solid'
  return 'stroke','Stroke / Outline'
 return 'original','Original'
def make_icon(name,entry,defaults,prefix,canonical=None):
 w=entry.get('width',defaults.get('width',16));h=entry.get('height',defaults.get('height',16));left=entry.get('left',0);top=entry.get('top',0)
 body=safe_body(entry['body']);trans=[]
 if entry.get('hFlip'):trans+=['translate('+str(w+2*left)+' 0)','scale(-1 1)']
 if entry.get('vFlip'):trans+=['translate(0 '+str(h+2*top)+')','scale(1 -1)']
 rotation=entry.get('rotate',0)%4
 if rotation:trans.append(f'rotate({rotation*90} {left+w/2} {top+h/2})')
 if trans:body='<g transform="'+' '.join(trans)+'">'+body+'</g>'
 # Rotation uses the source canvas; current selected collections only rotate square aliases.
 if rotation%2 and w!=h:raise ValueError('Non-square rotated alias requires explicit canvas adapter: '+name)
 v,label=variant(name,prefix)
 svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="{left} {top} {w} {h}">'+body+'</svg>'
 obj=dict(name=name,width=w,height=h,body=body,variant=v,variantLabel=label)
 if left or top:obj.update(left=left,top=top)
 if canonical:obj['canonicalName']=canonical
 return obj
def resolve_alias(name,data,trail=()):
 if name in trail:raise ValueError('Alias cycle')
 if name in data['icons']:return dict(data['icons'][name]),name
 alias=dict(data['aliases'][name]);parent=alias.pop('parent');base,canonical=resolve_alias(parent,data,trail+(name,))
 for k,v in alias.items():
  if k in ['hFlip','vFlip']:base[k]=bool(base.get(k,False))!=bool(v)
  elif k=='rotate':base[k]=(base.get(k,0)+v)%4
  else:base[k]=v
 return base,canonical

def build(manifest,out,package=True):
 out.mkdir(parents=True,exist_ok=True);target=out/'batches/icon-series';target.mkdir(parents=True,exist_ok=True)
 for f in ['runtime.js','runtime.css']:shutil.copy2(HERE/f,target/f)
 items=[];stats=[]
 for m in manifest:
  prefix=m['prefix'];source=Path(m['sourceDir']);raw=json.loads((source/'icons.json').read_text());license=m['license']['spdx'];licpath=Path(m['upstreamLicenseFile'])
  if prefix=='lucide':license='ISC + MIT (Feather-derived icons)'
  icons=[make_icon(n,e,raw,prefix)for n,e in sorted(raw['icons'].items())];aliases={}
  for n in sorted(raw.get('aliases',{})):
   e,canon=resolve_alias(n,raw);aliases[n]=make_icon(n,e,raw,prefix,canon)
  variants=[dict(id=v,label=label)for v,label in sorted({(x['variant'],x['variantLabel'])for x in icons})]
  data=dict(name=m['name'],prefix=prefix,license=license,icons=icons,aliases=aliases,aliasCount=len(aliases),variants=variants)
  payload=json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')
  page='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+html.escape(m['name'])+' · UI Vault</title><link rel="stylesheet" href="runtime.css"></head><body><div id="root"></div><script type="application/json" id="icon-data">'+payload+'</script><script src="runtime.js"></script></body></html>'
  (target/(prefix+'.html')).write_text(page)
  shutil.copy2(licpath,target/(prefix+'-LICENSE.txt'))
  example=icons[0];exampleSVG=f'<svg xmlns="http://www.w3.org/2000/svg" width="{example["width"]}" height="{example["height"]}" viewBox="0 0 {example["width"]} {example["height"]}">'+example['body']+'</svg>'
  usage='// '+m['name']+' · '+license+' · '+m['author']['name']+'\n// Full unmodified icons.json/info.json and license are in the source ZIP.\n// Browse this collection, select an icon, then select its SVG source.\n// This example uses a trusted bundled vector, not arbitrary user HTML.\nexport const iconName = '+json.dumps(example['name'])+';\nexport const svgSource = '+json.dumps(exampleSVG)+';\nexport function mountIcon(container, size = 24) {\n  const parsed = new DOMParser().parseFromString(svgSource, "image/svg+xml");\n  const svg = document.importNode(parsed.documentElement, true);\n  svg.setAttribute("width", String(size));\n  svg.setAttribute("height", String(size));\n  container.replaceChildren(svg);\n}\n'
  (target/(prefix+'-usage.js')).write_text(usage)
  base='batches/icon-series/'
  items.append(dict(id='icons:'+prefix,title=m['name']+' 完整图标系列',category='图标系列',kind='图标系列',source=m['name'],license=license,keywords=m['name']+' icons svg 图标 系列 搜索 '+prefix,description=f'{len(icons):,} 个原包条目（含原生样式、尺寸及旧名），另有 {len(aliases)} 个别名；整套仅计 1 个素材系列。按名称搜索、本地每页60、原生样式筛选与SVG源码查看。',technology=['SVG','Vanilla JavaScript'],style='图标系列',preview=base+prefix+'.html',code=base+prefix+'-usage.js',bundle=base+prefix+'-source.zip',upstream=m['author']['url'],website=m['author']['url'],revision=m['package']+'@'+m['version'],dependencies='预览零npm运行依赖；本地IIFE/CSS/内嵌SVG数据，源码包以Python标准库重建。',adaptation='上游SVG向量及许可原件保留；生成器严格SVG白名单验证。只改变预览尺寸，不伪造笔画/填充。原生variant通过名称筛选；别名单独标注不计新增图标。',behavior='搜索icon名称；前后翻页每页最多60；16/24/32切换仅显示尺寸；点击图标出现名称/SVG源码与Select SVG source；存在原生variant的系列可筛选Stroke/Fill等；无剪贴板权限请求。',thumbnailSize='wide',featured=True,runtime=dict(key='icon-series',css=base+'runtime.css',js=base+'runtime.js',cssHref='runtime.css',scriptSrc='runtime.js')))
  stats.append(dict(prefix=prefix,canonical=len(icons),aliases=len(aliases),variants=variants,htmlBytes=len(page.encode()),sourceSha256=hashlib.sha256((source/'icons.json').read_bytes()).hexdigest()))
  if package:
   local=dict(m,sourceDir='source',upstreamLicenseFile='source/UPSTREAM-LICENSE.txt')
   with zipfile.ZipFile(target/(prefix+'-source.zip'),'w',zipfile.ZIP_DEFLATED)as z:
    for f in ['icons.json','info.json','package.json']:
     z.write(source/f,'source/'+f)
    for f in source.iterdir():
     if f.is_file() and re.match('(?i)(license|notice)',f.name):z.write(f,'source/'+f.name)
    z.write(licpath,'source/UPSTREAM-LICENSE.txt')
    for f in ['build.py','runtime.js','runtime.css']:z.write(HERE/f,'generator/'+f)
    z.writestr('manifest.json',json.dumps([local],ensure_ascii=False,indent=2));z.writestr('README.md',f'# {m["name"]} icon collection\n\nOriginal {m["package"]}@{m["version"]}. Full original icons.json, info.json and package metadata plus upstream license included. {len(icons)} canonical entries and {len(aliases)} aliases. The whole collection is one atlas item; native style/size variants are not extra atlas entries.\n\nBuild offline with Python3 standard library only: `python generator/build.py --manifest manifest.json --out build --no-zip`. No npm installation or credentials. `build/batches/icon-series/{prefix}.html` is the complete preview. Serve locally or open HTML; no network resources needed.\n\nGenerator is an independent UI Vault adapter. It validates SVG element/attribute allowlists and rejects executable/external references, preserves original vectors, resolves aliases, adds local search/pagination/size/selection UI. Native variants are filtered by original names; outlines are not synthesized from filled vectors. Original package bytes remain unchanged in source/.\n')
 print(json.dumps(stats,ensure_ascii=False,indent=2));(out/'items-additions.json').write_text(json.dumps(items,ensure_ascii=False,indent=2));(out/'build-report.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2));return items
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--manifest',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--no-zip',action='store_true');a=p.parse_args();build(json.loads(a.manifest.read_text()),a.out,not a.no_zip)
