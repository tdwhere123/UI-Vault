# Lucide icon collection

Original @iconify-json/lucide@1.2.152. Full original icons.json, info.json and package metadata plus upstream license included. 2109 canonical entries and 237 aliases. The whole collection is one atlas item; native style/size variants are not extra atlas entries.

Build offline with Python3 standard library only: `python generator/build.py --manifest manifest.json --out build --no-zip`. No npm installation or credentials. `build/batches/icon-series/lucide.html` is the complete preview. Serve locally or open HTML; no network resources needed.

Generator is an independent UI Vault adapter. It validates SVG element/attribute allowlists and rejects executable/external references, preserves original vectors, resolves aliases, adds local search/pagination/size/selection UI. Native variants are filtered by original names; outlines are not synthesized from filled vectors. Original package bytes remain unchanged in source/.
