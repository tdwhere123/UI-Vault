import * as React from 'react';import {createRoot} from 'react-dom/client';import './styles.css';
import Demo0 from './demos/light-rays';
import Demo1 from './demos/scroll-based-velocity';
import Demo2 from './demos/text-reveal';
import Demo3 from './demos/smooth-cursor';
import Demo4 from './demos/lens';
import Demo5 from './demos/pixel-image';
const demos={'light-rays':Demo0,'scroll-based-velocity':Demo1,'text-reveal':Demo2,'smooth-cursor':Demo3,'lens':Demo4,'pixel-image':Demo5};const root=document.getElementById('root')!;const Demo=demos[root.dataset.demo as keyof typeof demos];createRoot(root).render(<div className={'stage stage-'+root.dataset.demo}><Demo/></div>);