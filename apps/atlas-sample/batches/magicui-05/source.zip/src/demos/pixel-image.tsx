import { PixelImage } from "@/registry/magicui/pixel-image"

export default function Home() {
  return (
    <PixelImage
      src="data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20720%20520%22%3E%3Crect%20width%3D%22720%22%20height%3D%22520%22%20fill%3D%22%23e8e1d3%22%2F%3E%3Ccircle%20cx%3D%22516%22%20cy%3D%22130%22%20r%3D%2274%22%20fill%3D%22%23d67a53%22%2F%3E%3Cpath%20d%3D%22M0%20325%20180%20135%20380%20330%20548%20211%20720%20360V520H0Z%22%20fill%3D%22%238b9b8b%22%2F%3E%3Cpath%20d%3D%22M0%20403%20208%20283%20363%20397%20575%20315%20720%20421V520H0Z%22%20fill%3D%22%23455d58%22%2F%3E%3Cpath%20d%3D%22M0%20465c180-74%20310%2036%20720-12v67H0Z%22%20fill%3D%22%23263e3a%22%2F%3E%3Cpath%20d%3D%22M372%20520%20446%20382%20493%20382%20451%20520Z%22%20fill%3D%22%23e8b87d%22%2F%3E%3Ctext%20x%3D%2242%22%20y%3D%2266%22%20fill%3D%22%23263e3a%22%20font-family%3D%22sans-serif%22%20font-size%3D%2218%22%20letter-spacing%3D%227%22%3EFIELD%20NOTES%3C%2Ftext%3E%3Ctext%20x%3D%2240%22%20y%3D%22109%22%20fill%3D%22%23263e3a%22%20font-family%3D%22sans-serif%22%20font-size%3D%2234%22%20font-weight%3D%22600%22%3ESomewhere%20quieter.%3C%2Ftext%3E%3Ctext%20x%3D%2244%22%20y%3D%22488%22%20fill%3D%22%23e8e1d3%22%20font-family%3D%22sans-serif%22%20font-size%3D%2213%22%20letter-spacing%3D%223%22%3EORIGINAL%20DEMO%20ART%20%2F%20UI%20VAULT%3C%2Ftext%3E%3C%2Fsvg%3E"
      customGrid={{ rows: 4, cols: 6 }}
      grayscaleAnimation
    />
  )
}

