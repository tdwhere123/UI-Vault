export function usePathname(){ return '/'; }
export function useRouter(){ return { push(){}, replace(){}, prefetch(){}, back(){} }; }
export function useSearchParams(){ return new URLSearchParams(); }
