import React from "react";import {createRoot} from "react-dom/client";import "./styles.css";
import C0 from "./components/stack-panel.tsx";
import C1 from "./components/stay-picker.tsx";
import C2 from "./components/wheel-picker.tsx";
import C3 from "./components/uptime-card.tsx";
import C4 from "./components/timezone-planner.tsx";
import C5 from "./components/topo-background.tsx";
const demos={"stack-panel": C0,"stay-picker": C1,"wheel-picker": C2,"uptime-card": C3,"timezone-planner": C4,"topo-background": C5};
const name=document.body.dataset.demo;const Demo=demos[name];if(!Demo)throw Error("Unknown demo: "+name);createRoot(document.getElementById("root")).render(<div className="demo-stage"><Demo/></div>);
