带页签的商品详情
来源：https://github.com/michael-andreuzza/oxbow/blob/26dca641b305a5ee93f57e57a1888a3807c0c273/src/components/oxbow/ecommerce/product-details/04.astro
许可：MIT（见LICENSE.txt）
original.html 为官方 astro build 生成的 iframe 预览页未改原文。
preview.html 使用官方构建抽出的 CSS，以及官方依赖中的 Alpine 3.15.12；未引入官方文档页那份含高亮器的大型 page 脚本。
交互范围：查看商品详情并切换说明页签（演示操作已拦截）
本地适配不等于源交互已验证，也没有真实浏览器视觉验收或封面。
