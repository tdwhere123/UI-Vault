"use client";

import {
  Attachment,
  AttachmentPreview,
  AttachmentRemove,
  Attachments,
} from "@repo/elements/attachments";
import { nanoid } from "nanoid";
import { memo, useCallback, useState } from "react";

const initialAttachments = [
  {
    filename: "local-blue-landscape.svg",
    id: nanoid(),
    mediaType: "image/svg+xml",
    type: "file" as const,
    url: "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22300%22%20height%3D%22220%22%3E%3Crect%20width%3D%22300%22%20height%3D%22220%22%20fill%3D%22%23bfdbfe%22%2F%3E%3Ccircle%20cx%3D%22220%22%20cy%3D%2260%22%20r%3D%2227%22%20fill%3D%22%23fff%22%2F%3E%3Cpath%20d%3D%22M0%20220L100%2055L200%20220ZM100%20220L210%2090L300%20220Z%22%20fill%3D%22%23334155%22%2F%3E%3C%2Fsvg%3E",
  },
  {
    filename: "local-amber-landscape.svg",
    id: nanoid(),
    mediaType: "image/svg+xml",
    type: "file" as const,
    url: "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22300%22%20height%3D%22220%22%3E%3Crect%20width%3D%22300%22%20height%3D%22220%22%20fill%3D%22%23fed7aa%22%2F%3E%3Ccircle%20cx%3D%22220%22%20cy%3D%2260%22%20r%3D%2227%22%20fill%3D%22%23fff%22%2F%3E%3Cpath%20d%3D%22M0%20220L100%2055L200%20220ZM100%20220L210%2090L300%20220Z%22%20fill%3D%22%23334155%22%2F%3E%3C%2Fsvg%3E",
  },
  {
    filename: "document.pdf",
    id: nanoid(),
    mediaType: "application/pdf",
    type: "file" as const,
    url: "",
  },
  {
    filename: "video.mp4",
    id: nanoid(),
    mediaType: "video/mp4",
    type: "file" as const,
    url: "",
  },
];

interface AttachmentItemProps {
  attachment: (typeof initialAttachments)[0];
  onRemove: (id: string) => void;
}

const AttachmentItem = memo(({ attachment, onRemove }: AttachmentItemProps) => {
  const handleRemove = useCallback(
    () => onRemove(attachment.id),
    [onRemove, attachment.id]
  );
  return (
    <Attachment data={attachment} onRemove={handleRemove}>
      <AttachmentPreview />
      <AttachmentRemove />
    </Attachment>
  );
});

AttachmentItem.displayName = "AttachmentItem";

const Example = () => {
  const [attachments, setAttachments] = useState(initialAttachments);

  const handleRemove = useCallback((id: string) => {
    setAttachments((prev) => prev.filter((a) => a.id !== id));
  }, []);

  return (
    <div className="flex items-center justify-center p-8">
      <Attachments variant="grid">
        {attachments.map((attachment) => (
          <AttachmentItem
            attachment={attachment}
            key={attachment.id}
            onRemove={handleRemove}
          />
        ))}
      </Attachments>
    </div>
  );
};

export default Example;
