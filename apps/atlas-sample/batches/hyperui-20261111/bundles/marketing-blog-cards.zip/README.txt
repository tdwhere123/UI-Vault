博文卡片
来源：https://github.com/markmead/hyperui/blob/637323c8d3046645ac5f28edc2074d18f22a2b94/public/examples/marketing/blog-cards/1.html
许可：MIT（见LICENSE.txt）
original.html为未改动原件。
preview.html配合同目录runtime.css与runtime.js本地打开；CSS已编译，无CDN。
预览中有1处远程图片或标识已替换为本地原创占位图，不把远程素材当作已授权收录。
交互范围：浏览博文卡片（远程照片已换成本地占位图）
未做真实浏览器视觉与交互验收，也没有真实运行页面封面。
