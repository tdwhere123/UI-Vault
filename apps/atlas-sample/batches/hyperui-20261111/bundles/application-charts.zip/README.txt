收入趋势图
来源：https://github.com/markmead/hyperui/blob/637323c8d3046645ac5f28edc2074d18f22a2b94/public/examples/application/charts/1.html
许可：MIT（见LICENSE.txt）
original.html为未改动原件。
preview.html配合同目录runtime.css与runtime.js本地打开；CSS已编译，无CDN。
图表使用已保存的Chart.js 4.5.1（MIT），不加载CDN。
交互范围：切换时间范围并查看本地图表（Chart.js 已内置）
未做真实浏览器视觉与交互验收，也没有真实运行页面封面。
