文件上传
来源：https://github.com/markmead/hyperui/blob/637323c8d3046645ac5f28edc2074d18f22a2b94/public/examples/application/file-uploaders/1.html
许可：MIT（见LICENSE.txt）
original.html为未改动原件。
preview.html配合同目录runtime.css与runtime.js本地打开；CSS已编译，无CDN。
交互范围：选择文件控件（实际上传已拦截）
未做真实浏览器视觉与交互验收，也没有真实运行页面封面。
