下拉菜单
来源：https://github.com/markmead/hyperui/blob/637323c8d3046645ac5f28edc2074d18f22a2b94/public/examples/application/dropdown/1.html
许可：MIT（见LICENSE.txt）
original.html为未改动原件。官方示例是静态展开菜单，官方 component.js 只拦截链接与表单，不提供开闭。
preview.html配合同目录runtime.css、runtime.js与本地预览适配器dropdown-menu-preview.js打开；CSS已编译，无CDN。
适配器仅用于可交互预览：初始收起，菜单按钮切换开闭，并处理Escape、点击外部与选项后收回；提供必要的aria-expanded、aria-controls与aria-haspopup。不改变链接与表单拦截，不改原件。
交互范围：预览适配器展开/收起下拉选项（演示链接已拦截）
未做真实浏览器视觉与交互验收，也没有真实运行页面封面。
