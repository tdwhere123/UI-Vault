分析看板整页
来源：https://github.com/markmead/hyperui/blob/637323c8d3046645ac5f28edc2074d18f22a2b94/public/examples/templates/analytics-dashboard/1.html
许可：MIT（见LICENSE.txt）
original.html为未改动原件。
preview.html配合同目录runtime.css与runtime.js本地打开；CSS已编译，无CDN。
预览中有1处远程图片或标识已替换为本地原创占位图，不把远程素材当作已授权收录。
图表使用已保存的Chart.js 4.5.1（MIT），不加载CDN。
交互范围：切换侧栏、时间范围并查看本地图表（头像已换占位图）
未做真实浏览器视觉与交互验收，也没有真实运行页面封面。
