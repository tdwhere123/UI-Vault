// Unique CSS output: esbuild may emit imported component CSS next to runtime.js.
// Tailwind writes a sibling file; the two are merged into the single runtime.css. Tailwind must not overwrite component CSS.
import {build} from "esbuild";
import path from "node:path";
import fs from "node:fs";
import {execFileSync} from "node:child_process";
const alias = {
  "@": path.resolve("src"),
  "next/image": path.resolve("src/shims/next-image.tsx"),
  "next/link": path.resolve("src/shims/next-link.tsx"),
};
await build({
  entryPoints: ["src/entry.tsx"],
  bundle: true,
  format: "iife",
  platform: "browser",
  outfile: "runtime.js",
  jsx: "automatic",
  minify: true,
  define: {"process.env.NODE_ENV": '"production"'},
  alias,
});
const componentCss = fs.existsSync("runtime.css") ? fs.readFileSync("runtime.css", "utf8") : "";
execFileSync("./node_modules/.bin/tailwindcss", ["-i", "src/global.css", "-o", "runtime.tailwind.css", "--minify"], {stdio: "inherit"});
const tailwindCss = fs.readFileSync("runtime.tailwind.css", "utf8");
fs.writeFileSync("runtime.css", tailwindCss + (componentCss ? "\n" + componentCss : ""));
