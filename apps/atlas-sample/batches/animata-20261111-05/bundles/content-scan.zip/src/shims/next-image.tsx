import React from "react";

export function resolveAtlasAsset(src: any) {
  const map = typeof window !== "undefined" ? (window as any).__atlasAssets : undefined;
  if (src == null || !map) return src;
  const raw = String(src);
  if (raw.startsWith("blob:") || raw.startsWith("data:")) return raw;
  const noHash = raw.split("#")[0];
  const path = noHash.split("?")[0];
  const base = path.split("/").pop() || "";
  const keys = [raw, noHash, path, base, base ? "assets/" + base : ""].filter(Boolean);
  for (const key of keys) {
    if (Object.prototype.hasOwnProperty.call(map, key) && map[key]) return map[key];
  }
  return src;
}

export default function Image({src, alt, width, height, fill, className, style, ...rest}: any) {
  const resolved = resolveAtlasAsset(src);
  return <img src={resolved} alt={alt || ""} width={width} height={height} className={className} style={style} {...rest} />;
}
