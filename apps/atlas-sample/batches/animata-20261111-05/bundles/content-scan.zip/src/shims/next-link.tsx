import React from "react";
export default function Link({href, children, className, ...p}: any) {
  return <a href={href || "#"} className={className} {...p}>{children}</a>;
}
