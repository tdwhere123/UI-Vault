批量邀请对话框
来源：https://github.com/merakiui/merakiui/blob/fe0472efe93f6cd275424ecbdfa7f6cb8da6f908/components/modals/MultiInvites.html
许可：MIT（见LICENSE.txt）
original.* 为固定修订上的未改动原件或从文档摘出的原始示例标记。
preview.html 配合同目录 runtime.css 与 runtime.js 本地打开；无CDN。
交互范围：查看批量邀请对话框（提交已拦截）
预览中的拦截脚本或内置库是本线加入的本地适配，不表示源交互已验证，也不表示后端业务成功。
未做真实浏览器视觉与交互验收，也没有真实运行页面封面。
