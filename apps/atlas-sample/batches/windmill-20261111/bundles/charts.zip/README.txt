图表页
来源：https://github.com/estevanmaito/windmill-dashboard/blob/e05267588134ca2f4129087cc65a59c38a9c36b5/public/charts.html
许可：MIT；Chart.js 2.9.3 与 Alpine 许可在源码包内。
已内置官方图表脚本。未做浏览器验收，无封面。
