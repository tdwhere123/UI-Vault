应用空白壳
来源：https://github.com/estevanmaito/windmill-dashboard/blob/e05267588134ca2f4129087cc65a59c38a9c36b5/public/pages/blank.html
许可：MIT（见LICENSE.txt）；Chart.js 2.9.3 与 Alpine 许可在源码包内。
preview.html 配合同目录 runtime.css、runtime.js 与 assets/ 本地打开。
交互范围：查看带侧栏的应用空白壳（演示链接已拦截）
图表初始化与拦截脚本是本线本地适配，不表示已在真实浏览器完成视觉或交互验收，也没有真实封面。
