找回密码页
来源：https://github.com/estevanmaito/windmill-dashboard/blob/e05267588134ca2f4129087cc65a59c38a9c36b5/public/pages/forgot-password.html
许可：MIT（见LICENSE.txt）；Chart.js 2.9.3 与 Alpine 许可在源码包内。
preview.html 配合同目录 runtime.css、runtime.js 与 assets/ 本地打开。
交互范围：填写找回密码表单（提交已拦截，办公场景照片为官方仓库原件本地副本）
图表初始化与拦截脚本是本线本地适配，不表示已在真实浏览器完成视觉或交互验收，也没有真实封面。
