Official component logic retained in a previously compiled preview runtime. Originals added from the official repository at the recorded revision. Browser QA pending.
