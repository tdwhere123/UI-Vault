Original upstream component logic retained. Only preview shell added, system-font fallback used, and neutral page background applied. No remote photos used. Bencho source uses its bundled inline SVG placeholders. Component CSS and theme tokens retained. Original files are in originals/. Build with npm ci then npm run build. Browser visual/interaction QA pending.

QA fix: missing /lab and /blocks image references replaced with locally authored neutral SVG landscapes. Original sources retained in originals.
