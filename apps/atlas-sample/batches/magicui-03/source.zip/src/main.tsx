import * as React from 'react';import {createRoot} from 'react-dom/client';import './styles.css';
import Demo0 from './demos/kinetic-text';
import Demo1 from './demos/aurora-text';
import Demo2 from './demos/meteors';
import Demo3 from './demos/line-shadow-text';
import Demo4 from './demos/interactive-grid-pattern';
import Demo5 from './demos/flickering-grid';
const demos={'kinetic-text':Demo0,'aurora-text':Demo1,'meteors':Demo2,'line-shadow-text':Demo3,'interactive-grid-pattern':Demo4,'flickering-grid':Demo5};const root=document.getElementById('root')!;const Demo=demos[root.dataset.demo as keyof typeof demos];createRoot(root).render(<div className={'stage stage-'+root.dataset.demo}><Demo/></div>);