# magicui-03

Six distinct Magic UI materials, not six copies of one component. originals/ preserves original components, examples and registry CSS; src/ contains the actual adapted demo and local dependency source.

Node24 recommended. npm ci then npm run build. All direct versions are pinned; package-lock is included. No node_modules in this archive.

preview/ uses production IIFE and local CSS, system fonts and local SVG only. Serve preview/ with a static HTTP server. No external service or account is used.

Magic UI MIT and all actual bundled npm notices included. The sample themes are fixed light; brand marks in the beam example are replaced with simple original SVG shapes.
