import {build} from 'esbuild';import fs from 'node:fs';import path from 'node:path';import {execFileSync} from 'node:child_process';
const list=JSON.parse(fs.readFileSync('selection.json'));fs.mkdirSync('delivery/batches',{recursive:true});
for(let n=1;n<=4;n++){
const dir=`delivery/batches/animata-${String(n).padStart(2,'0')}`;fs.mkdirSync(dir,{recursive:true});
await build({entryPoints:[`src/entry-${n}.tsx`],bundle:true,format:'iife',platform:'browser',outfile:`${dir}/runtime.js`,jsx:'automatic',minify:true,define:{'process.env.NODE_ENV':'"production"'},alias:{'@':path.resolve('src')}});
execFileSync('./node_modules/.bin/tailwindcss',['-i','src/global.css','-o',`${dir}/tailwind.css`,'--minify']);
const extra=fs.existsSync(`${dir}/runtime.css`)?fs.readFileSync(`${dir}/runtime.css`,'utf8'):'';fs.writeFileSync(`${dir}/runtime.css`,fs.readFileSync(`${dir}/tailwind.css`,'utf8'));fs.unlinkSync(`${dir}/tailwind.css`);
for(const s of list.slice((n-1)*7,n*7)){const key=s.split('/').pop();fs.writeFileSync(`${dir}/${key}.html`,`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="runtime.css"><title>${key}</title></head><body data-component="${key}"><div id="root"></div><script src="runtime.js"></script></body></html>`);}
}
