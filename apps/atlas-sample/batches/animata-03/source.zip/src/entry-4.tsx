import React from "react"; import {createRoot} from "react-dom/client";
import * as S0 from "./animata/fabs/speed-dial.stories";
import * as S1 from "./animata/background/boids-ecosystem.stories";
import * as S2 from "./animata/background/interactive-grid.stories";
import * as S3 from "./animata/background/shooting-stars.stories";
import * as S4 from "./animata/graphs/gauge-chart.stories";
import * as S5 from "./animata/graphs/commit-graph.stories";
import * as S6 from "./animata/graphs/ring-chart.stories";
const stories={"speed-dial":S0,"boids-ecosystem":S1,"interactive-grid":S2,"shooting-stars":S3,"gauge-chart":S4,"commit-graph":S5,"ring-chart":S6}; const key=document.body.dataset.component; const S=stories[key]; const meta=S.default; const story=S.Primary||Object.entries(S).find(([k,v])=>k!=="default"&&v&&typeof v==="object")[1]; const args={...meta.args,...story.args}; const Comp=meta.component; createRoot(document.getElementById("root")).render(story.render?story.render(args):<Comp {...args}/>);