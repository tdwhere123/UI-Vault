import React from "react"; import {createRoot} from "react-dom/client";
import * as S0 from "./animata/card/led-board.stories";
import * as S1 from "./animata/card/card-spread.stories";
import * as S2 from "./animata/card/email-feature-card.stories";
import * as S3 from "./animata/card/blur-stack-card.stories";
import * as S4 from "./animata/card/collab-card.stories";
import * as S5 from "./animata/card/integration-pills.stories";
import * as S6 from "./animata/widget/storage-widget.stories";
const stories={"led-board":S0,"card-spread":S1,"email-feature-card":S2,"blur-stack-card":S3,"collab-card":S4,"integration-pills":S5,"storage-widget":S6}; const key=document.body.dataset.component; const S=stories[key]; const meta=S.default; const story=S.Primary||Object.entries(S).find(([k,v])=>k!=="default"&&v&&typeof v==="object")[1]; const args={...meta.args,...story.args}; const Comp=meta.component; createRoot(document.getElementById("root")).render(story.render?story.render(args):<Comp {...args}/>);