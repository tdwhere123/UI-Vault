import React from "react"; import {createRoot} from "react-dom/client";
import * as S0 from "./animata/widget/weekly-progress.stories";
import * as S1 from "./animata/widget/notes.stories";
import * as S2 from "./animata/widget/team-clock.stories";
import * as S3 from "./animata/widget/calendar-event.stories";
import * as S4 from "./animata/widget/study-timer.stories";
import * as S5 from "./animata/widget/shopping-list.stories";
import * as S6 from "./animata/widget/alarm-clock.stories";
const stories={"weekly-progress":S0,"notes":S1,"team-clock":S2,"calendar-event":S3,"study-timer":S4,"shopping-list":S5,"alarm-clock":S6}; const key=document.body.dataset.component; const S=stories[key]; const meta=S.default; const story=S.Primary||Object.entries(S).find(([k,v])=>k!=="default"&&v&&typeof v==="object")[1]; const args={...meta.args,...story.args}; const Comp=meta.component; createRoot(document.getElementById("root")).render(story.render?story.render(args):<Comp {...args}/>);