import React from "react"; import {createRoot} from "react-dom/client";
import * as S0 from "./animata/widget/vpn-widget.stories";
import * as S1 from "./animata/widget/water-tracker.stories";
import * as S2 from "./animata/widget/reminder-widget.stories";
import * as S3 from "./animata/container/fibonacci-lines.stories";
import * as S4 from "./animata/container/sibling-focus-nav.stories";
import * as S5 from "./animata/tabs/gooey-tabs.stories";
import * as S6 from "./animata/tabs/fluid-tabs.stories";
const stories={"vpn-widget":S0,"water-tracker":S1,"reminder-widget":S2,"fibonacci-lines":S3,"sibling-focus-nav":S4,"gooey-tabs":S5,"fluid-tabs":S6}; const key=document.body.dataset.component; const S=stories[key]; const meta=S.default; const story=S.Primary||Object.entries(S).find(([k,v])=>k!=="default"&&v&&typeof v==="object")[1]; const args={...meta.args,...story.args}; const Comp=meta.component; createRoot(document.getElementById("root")).render(story.render?story.render(args):<Comp {...args}/>);