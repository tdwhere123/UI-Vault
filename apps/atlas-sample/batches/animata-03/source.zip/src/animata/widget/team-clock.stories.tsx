import type { Meta, StoryObj } from "@storybook/react";
import TeamClock from "@/animata/widget/team-clock";

const testTeamClockProps = {
  users: [
    {
      name: "User 1",
      city: "New York",
      country: "USA",
      timeDifference: "-5",
      pfp: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='80' height='80'%3E%3Crect width='80' height='80' rx='40' fill='%23a7f3d0'/%3E%3Ccircle cx='40' cy='30' r='12' fill='%23065f46'/%3E%3Cpath d='M18 67a22 22 0 0144 0' fill='%23065f46'/%3E%3C/svg%3E",
    },
    {
      name: "User 2",
      city: "London",
      country: "UK",
      timeDifference: "+5",
      pfp: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='80' height='80'%3E%3Crect width='80' height='80' rx='40' fill='%23a7f3d0'/%3E%3Ccircle cx='40' cy='30' r='12' fill='%23065f46'/%3E%3Cpath d='M18 67a22 22 0 0144 0' fill='%23065f46'/%3E%3C/svg%3E",
    },
  ],
  clockSize: 250,
  animationDuration: 0.3,
  accentColor: "#34D399",
  backgroundColor: "#ECFDF5",
  textColor: "#065F46",
  borderColor: "#D1FAE5",
  hoverBackgroundColor: "#D1FAE5",
  showSeconds: true,
  use24HourFormat: false,
};

const meta = {
  title: "Widget/Team Clock",
  component: TeamClock,
  parameters: {
    layout: "centered",
  },
  tags: ["autodocs"],
  argTypes: {},
} satisfies Meta<typeof TeamClock>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Primary: Story = {
  args: testTeamClockProps,
};
