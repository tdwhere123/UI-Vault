import Image from 'next/image'
import { HeroHeader } from '@/registry/bases/radix/dusk/blocks/hero-section/six/header'
import { cn } from '@/registry/core/lib/utils'
import { Google } from '@/registry/core/ui/svgs/google'
import { Trustpilot } from '@/registry/core/ui/svgs/trustpilot'
import { G2 } from '@/registry/core/ui/svgs/g2'

type ProfileCardProps = {
    name: string
    alt: string
    imageSrc: string
    className?: string
    cardClassName?: string
    rightMaskClassName?: string
}

const ProfileCard = ({ name, alt, imageSrc, className, cardClassName, rightMaskClassName }: ProfileCardProps) => {
    return (
        <div
            aria-hidden
            className={cn('absolute inset-0 z-10 m-auto size-fit', className)}
        >
            <div className="border-foreground/25 mask-radial-from-bottom-left mask-radial-from-65% mask-radial-[100%_60%] absolute inset-y-0 left-0 z-10 aspect-video rounded-l-2xl border-l border-t" />
            <div className={cn('border-foreground/25 mask-radial-from-bottom-right mask-radial-from-65% mask-radial-[60%_100%] absolute inset-y-0 right-0 z-10 aspect-video rounded-r-2xl border-r border-t', rightMaskClassName)} />

            <div className="relative overflow-hidden rounded-2xl border border-zinc-900/50 shadow-2xl shadow-black ring ring-black/50">
                <Image
                    src={imageSrc}
                    alt={alt}
                    width={120}
                    height={120}
                    className="absolute inset-0 my-auto size-fit blur"
                />
                <div className={cn('relative z-10 rounded-2xl p-2 pr-32 backdrop-blur dark:bg-zinc-900/80', cardClassName)}>
                    <div className="flex gap-2">
                        <div className="before:border-foreground/20 size-18 relative overflow-hidden rounded-xl shadow-md before:absolute before:inset-0 before:rounded-xl before:border">
                            <Image
                                src={imageSrc}
                                alt={alt}
                                width={136}
                                height={136}
                            />
                        </div>
                        <div className="py-1 pr-4">
                            <div className="text-sm font-medium">{name}</div>
                            <div className="mt-1.5 flex items-center gap-3">
                                <div>
                                    <div className="text-foreground/50 text-xs">Expenses</div>
                                    <div className="mt-0.5 text-sm font-semibold">$32.65k</div>
                                </div>
                                <div className="bg-border h-7 w-px" />
                                <div>
                                    <div className="text-foreground/50 text-xs">Income</div>
                                    <div className="mt-0.5 text-sm font-semibold">$2.65k</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default function HeroSection() {
    return (
        <>
            <HeroHeader />

            <main>
                <section className="pb-24 pt-40 md:pt-56">
                    <div className="relative mx-auto max-w-7xl px-6">
                        <div>
                            <h1 className="text-balance text-center text-4xl font-medium tracking-tight">
                                Family money, finally organized. <br /> <span className="text-muted-foreground">Plan budgets, bills, and savings together</span>
                            </h1>
                        </div>
                        <div className="sm:aspect-3/2 relative mx-auto mt-6 aspect-square max-w-4xl overflow-hidden">
                            <ProfileCard
                                name="Théo Balick"
                                alt="Théo's avatar"
                                imageSrc="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjAwIiBoZWlnaHQ9IjgwMCIgdmlld0JveD0iMCAwIDEyMDAgODAwIj48ZGVmcz48cmFkaWFsR3JhZGllbnQgaWQ9ImciPjxzdG9wIHN0b3AtY29sb3I9IiMyMmQzZWUiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiMwOTA5MGIiLz48L3JhZGlhbEdyYWRpZW50PjxsaW5lYXJHcmFkaWVudCBpZD0icyI+PHN0b3Agc3RvcC1jb2xvcj0iI2ZmZiIgc3RvcC1vcGFjaXR5PSIuNyIvPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iIzIyZDNlZSIgc3RvcC1vcGFjaXR5PSIuMSIvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMjAwIiBoZWlnaHQ9IjgwMCIgZmlsbD0iIzA5MDkwYiIvPjxlbGxpcHNlIGN4PSI2MDAiIGN5PSI0MjAiIHJ4PSI2MDAiIHJ5PSI1MDAiIGZpbGw9InVybCgjZykiIG9wYWNpdHk9Ii42Ii8+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSJ1cmwoI3MpIiBzdHJva2Utd2lkdGg9IjIiPjxlbGxpcHNlIGN4PSI2MDAiIGN5PSI0MTAiIHJ4PSI4MCIgcnk9IjcwIiB0cmFuc2Zvcm09InJvdGF0ZSgwIDYwMCA0MTApIi8+PGVsbGlwc2UgY3g9IjYwMCIgY3k9IjQxMCIgcng9IjEyNSIgcnk9IjkyIiB0cmFuc2Zvcm09InJvdGF0ZSg1IDYwMCA0MTApIi8+PGVsbGlwc2UgY3g9IjYwMCIgY3k9IjQxMCIgcng9IjE3MCIgcnk9IjExNCIgdHJhbnNmb3JtPSJyb3RhdGUoMTAgNjAwIDQxMCkiLz48ZWxsaXBzZSBjeD0iNjAwIiBjeT0iNDEwIiByeD0iMjE1IiByeT0iMTM2IiB0cmFuc2Zvcm09InJvdGF0ZSgxNSA2MDAgNDEwKSIvPjxlbGxpcHNlIGN4PSI2MDAiIGN5PSI0MTAiIHJ4PSIyNjAiIHJ5PSIxNTgiIHRyYW5zZm9ybT0icm90YXRlKDIwIDYwMCA0MTApIi8+PGVsbGlwc2UgY3g9IjYwMCIgY3k9IjQxMCIgcng9IjMwNSIgcnk9IjE4MCIgdHJhbnNmb3JtPSJyb3RhdGUoMjUgNjAwIDQxMCkiLz48ZWxsaXBzZSBjeD0iNjAwIiBjeT0iNDEwIiByeD0iMzUwIiByeT0iMjAyIiB0cmFuc2Zvcm09InJvdGF0ZSgzMCA2MDAgNDEwKSIvPjxlbGxpcHNlIGN4PSI2MDAiIGN5PSI0MTAiIHJ4PSIzOTUiIHJ5PSIyMjQiIHRyYW5zZm9ybT0icm90YXRlKDM1IDYwMCA0MTApIi8+PGVsbGlwc2UgY3g9IjYwMCIgY3k9IjQxMCIgcng9IjQ0MCIgcnk9IjI0NiIgdHJhbnNmb3JtPSJyb3RhdGUoNDAgNjAwIDQxMCkiLz48ZWxsaXBzZSBjeD0iNjAwIiBjeT0iNDEwIiByeD0iNDg1IiByeT0iMjY4IiB0cmFuc2Zvcm09InJvdGF0ZSg0NSA2MDAgNDEwKSIvPjxlbGxpcHNlIGN4PSI2MDAiIGN5PSI0MTAiIHJ4PSI1MzAiIHJ5PSIyOTAiIHRyYW5zZm9ybT0icm90YXRlKDUwIDYwMCA0MTApIi8+PGVsbGlwc2UgY3g9IjYwMCIgY3k9IjQxMCIgcng9IjU3NSIgcnk9IjMxMiIgdHJhbnNmb3JtPSJyb3RhdGUoNTUgNjAwIDQxMCkiLz48L2c+PC9zdmc+"
                                className="scale-85 z-11"
                                cardClassName="bg-card/75"
                                rightMaskClassName="border-foreground/35"
                            />

                            <ProfileCard
                                name="Shadcn"
                                alt="Shadcn avatar"
                                imageSrc="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjAwIiBoZWlnaHQ9IjgwMCIgdmlld0JveD0iMCAwIDEyMDAgODAwIj48ZGVmcz48cmFkaWFsR3JhZGllbnQgaWQ9ImciPjxzdG9wIHN0b3AtY29sb3I9IiM2MzY2ZjEiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiMwOTA5MGIiLz48L3JhZGlhbEdyYWRpZW50PjxsaW5lYXJHcmFkaWVudCBpZD0icyI+PHN0b3Agc3RvcC1jb2xvcj0iI2ZmZiIgc3RvcC1vcGFjaXR5PSIuNyIvPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iIzYzNjZmMSIgc3RvcC1vcGFjaXR5PSIuMSIvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMjAwIiBoZWlnaHQ9IjgwMCIgZmlsbD0iIzA5MDkwYiIvPjxlbGxpcHNlIGN4PSI2MDAiIGN5PSI0MjAiIHJ4PSI2MDAiIHJ5PSI1MDAiIGZpbGw9InVybCgjZykiIG9wYWNpdHk9Ii42Ii8+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSJ1cmwoI3MpIiBzdHJva2Utd2lkdGg9IjIiPjxlbGxpcHNlIGN4PSI2MDAiIGN5PSI0MTAiIHJ4PSI4MCIgcnk9IjcwIiB0cmFuc2Zvcm09InJvdGF0ZSgwIDYwMCA0MTApIi8+PGVsbGlwc2UgY3g9IjYwMCIgY3k9IjQxMCIgcng9IjEyNSIgcnk9IjkyIiB0cmFuc2Zvcm09InJvdGF0ZSg1IDYwMCA0MTApIi8+PGVsbGlwc2UgY3g9IjYwMCIgY3k9IjQxMCIgcng9IjE3MCIgcnk9IjExNCIgdHJhbnNmb3JtPSJyb3RhdGUoMTAgNjAwIDQxMCkiLz48ZWxsaXBzZSBjeD0iNjAwIiBjeT0iNDEwIiByeD0iMjE1IiByeT0iMTM2IiB0cmFuc2Zvcm09InJvdGF0ZSgxNSA2MDAgNDEwKSIvPjxlbGxpcHNlIGN4PSI2MDAiIGN5PSI0MTAiIHJ4PSIyNjAiIHJ5PSIxNTgiIHRyYW5zZm9ybT0icm90YXRlKDIwIDYwMCA0MTApIi8+PGVsbGlwc2UgY3g9IjYwMCIgY3k9IjQxMCIgcng9IjMwNSIgcnk9IjE4MCIgdHJhbnNmb3JtPSJyb3RhdGUoMjUgNjAwIDQxMCkiLz48ZWxsaXBzZSBjeD0iNjAwIiBjeT0iNDEwIiByeD0iMzUwIiByeT0iMjAyIiB0cmFuc2Zvcm09InJvdGF0ZSgzMCA2MDAgNDEwKSIvPjxlbGxpcHNlIGN4PSI2MDAiIGN5PSI0MTAiIHJ4PSIzOTUiIHJ5PSIyMjQiIHRyYW5zZm9ybT0icm90YXRlKDM1IDYwMCA0MTApIi8+PGVsbGlwc2UgY3g9IjYwMCIgY3k9IjQxMCIgcng9IjQ0MCIgcnk9IjI0NiIgdHJhbnNmb3JtPSJyb3RhdGUoNDAgNjAwIDQxMCkiLz48ZWxsaXBzZSBjeD0iNjAwIiBjeT0iNDEwIiByeD0iNDg1IiByeT0iMjY4IiB0cmFuc2Zvcm09InJvdGF0ZSg0NSA2MDAgNDEwKSIvPjxlbGxpcHNlIGN4PSI2MDAiIGN5PSI0MTAiIHJ4PSI1MzAiIHJ5PSIyOTAiIHRyYW5zZm9ybT0icm90YXRlKDUwIDYwMCA0MTApIi8+PGVsbGlwc2UgY3g9IjYwMCIgY3k9IjQxMCIgcng9IjU3NSIgcnk9IjMxMiIgdHJhbnNmb3JtPSJyb3RhdGUoNTUgNjAwIDQxMCkiLz48L2c+PC9zdmc+"
                                className="origin-top -translate-y-1 scale-75"
                                cardClassName="bg-white/90"
                            />

                            <Image
                                src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjAwIiBoZWlnaHQ9IjgwMCIgdmlld0JveD0iMCAwIDEyMDAgODAwIj48ZGVmcz48cmFkaWFsR3JhZGllbnQgaWQ9ImciPjxzdG9wIHN0b3AtY29sb3I9IiMyMmQzZWUiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiMwOTA5MGIiLz48L3JhZGlhbEdyYWRpZW50PjxsaW5lYXJHcmFkaWVudCBpZD0icyI+PHN0b3Agc3RvcC1jb2xvcj0iI2ZmZiIgc3RvcC1vcGFjaXR5PSIuNyIvPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iIzIyZDNlZSIgc3RvcC1vcGFjaXR5PSIuMSIvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMjAwIiBoZWlnaHQ9IjgwMCIgZmlsbD0iIzA5MDkwYiIvPjxlbGxpcHNlIGN4PSI2MDAiIGN5PSI0MjAiIHJ4PSI2MDAiIHJ5PSI1MDAiIGZpbGw9InVybCgjZykiIG9wYWNpdHk9Ii42Ii8+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSJ1cmwoI3MpIiBzdHJva2Utd2lkdGg9IjIiPjxlbGxpcHNlIGN4PSI2MDAiIGN5PSI0MTAiIHJ4PSI4MCIgcnk9IjcwIiB0cmFuc2Zvcm09InJvdGF0ZSgwIDYwMCA0MTApIi8+PGVsbGlwc2UgY3g9IjYwMCIgY3k9IjQxMCIgcng9IjEyNSIgcnk9IjkyIiB0cmFuc2Zvcm09InJvdGF0ZSg1IDYwMCA0MTApIi8+PGVsbGlwc2UgY3g9IjYwMCIgY3k9IjQxMCIgcng9IjE3MCIgcnk9IjExNCIgdHJhbnNmb3JtPSJyb3RhdGUoMTAgNjAwIDQxMCkiLz48ZWxsaXBzZSBjeD0iNjAwIiBjeT0iNDEwIiByeD0iMjE1IiByeT0iMTM2IiB0cmFuc2Zvcm09InJvdGF0ZSgxNSA2MDAgNDEwKSIvPjxlbGxpcHNlIGN4PSI2MDAiIGN5PSI0MTAiIHJ4PSIyNjAiIHJ5PSIxNTgiIHRyYW5zZm9ybT0icm90YXRlKDIwIDYwMCA0MTApIi8+PGVsbGlwc2UgY3g9IjYwMCIgY3k9IjQxMCIgcng9IjMwNSIgcnk9IjE4MCIgdHJhbnNmb3JtPSJyb3RhdGUoMjUgNjAwIDQxMCkiLz48ZWxsaXBzZSBjeD0iNjAwIiBjeT0iNDEwIiByeD0iMzUwIiByeT0iMjAyIiB0cmFuc2Zvcm09InJvdGF0ZSgzMCA2MDAgNDEwKSIvPjxlbGxpcHNlIGN4PSI2MDAiIGN5PSI0MTAiIHJ4PSIzOTUiIHJ5PSIyMjQiIHRyYW5zZm9ybT0icm90YXRlKDM1IDYwMCA0MTApIi8+PGVsbGlwc2UgY3g9IjYwMCIgY3k9IjQxMCIgcng9IjQ0MCIgcnk9IjI0NiIgdHJhbnNmb3JtPSJyb3RhdGUoNDAgNjAwIDQxMCkiLz48ZWxsaXBzZSBjeD0iNjAwIiBjeT0iNDEwIiByeD0iNDg1IiByeT0iMjY4IiB0cmFuc2Zvcm09InJvdGF0ZSg0NSA2MDAgNDEwKSIvPjxlbGxpcHNlIGN4PSI2MDAiIGN5PSI0MTAiIHJ4PSI1MzAiIHJ5PSIyOTAiIHRyYW5zZm9ybT0icm90YXRlKDUwIDYwMCA0MTApIi8+PGVsbGlwc2UgY3g9IjYwMCIgY3k9IjQxMCIgcng9IjU3NSIgcnk9IjMxMiIgdHJhbnNmb3JtPSJyb3RhdGUoNTUgNjAwIDQxMCkiLz48L2c+PC9zdmc+"
                                alt="background"
                                width={1280}
                                height={1000}
                                className="mask-x-from-80% mask-y-from-80% size-full object-cover max-sm:scale-150 dark:mix-blend-lighten"
                            />
                        </div>
                    </div>

                    <div className="mt-12">
                        <p className="text-muted-foreground text-center text-lg">Trusted by over 100,000 families</p>

                        <div className="mt-6 flex flex-wrap justify-center gap-x-12 gap-y-6">
                            <div className="flex items-center gap-2">
                                <Google className="size-5" />

                                <p className="text-foreground text-lg font-medium">
                                    <span>4.8</span> Google
                                </p>
                            </div>

                            <div className="flex items-center gap-2">
                                <Trustpilot className="size-5" />

                                <p className="text-foreground text-lg font-medium">
                                    <span>4.6</span> Trustpilot
                                </p>
                            </div>

                            <div className="flex items-center gap-2">
                                <G2 className="size-5" />

                                <p className="text-foreground text-lg font-medium">
                                    <span>4.5</span> G2
                                </p>
                            </div>
                        </div>
                    </div>
                </section>
            </main>
        </>
    )
}
