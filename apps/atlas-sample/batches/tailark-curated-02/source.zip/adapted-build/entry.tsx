import React from "react";import{createRoot}from"react-dom/client";import{ThemeProvider}from"next-themes";import"./runtime.css";
import C0 from "./registry/bases/radix/veil/blocks/integrations/two.tsx";
import C1 from "./registry/bases/radix/dusk/blocks/features/three.tsx";
import C2 from "./registry/bases/radix/dusk/blocks/integrations/one.tsx";
import C3 from "./registry/bases/radix/dusk/blocks/hero-section/eight.tsx";
const entries={"tailark:veil-integrations-two":C0,"tailark:dusk-features-three":C1,"tailark:dusk-integrations-one":C2,"tailark:dusk-hero-section-eight":C3};const r=document.getElementById("root");const C=entries[r.dataset.demo];createRoot(r).render(<ThemeProvider attribute="class" defaultTheme="light" enableSystem={false}><C/></ThemeProvider>);