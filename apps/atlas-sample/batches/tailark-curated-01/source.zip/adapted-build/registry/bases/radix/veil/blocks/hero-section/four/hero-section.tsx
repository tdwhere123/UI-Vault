import React from 'react'
import Link from 'next/link'
import { Button } from '@/registry/bases/radix/veil/ui/button'
import { HeroHeader } from '@/registry/bases/radix/veil/blocks/hero-section/four/header'
import { AudioLines, ChevronRight, Github, ImageIcon, Lightbulb, Mic2, Paperclip, Plus, ShoppingBag, Telescope } from 'lucide-react'
import Image from 'next/image'

export default function HeroSection() {
    return (
        <>
            <HeroHeader />
            <main className="overflow-hidden">
                <section className="bg-background">
                    <div className="relative py-32">
                        <div className="mask-radial-from-45% mask-radial-to-75% mask-radial-at-top mask-radial-[75%_100%] mask-t-from-50% aspect-2/3 lg:aspect-9/4 absolute inset-0 md:aspect-square dark:opacity-5">
                            <Image
                                src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjAwIiBoZWlnaHQ9IjgwMCIgdmlld0JveD0iMCAwIDEyMDAgODAwIj48ZGVmcz48cmFkaWFsR3JhZGllbnQgaWQ9ImciPjxzdG9wIHN0b3AtY29sb3I9IiMyMmQzZWUiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiMwOTA5MGIiLz48L3JhZGlhbEdyYWRpZW50PjxsaW5lYXJHcmFkaWVudCBpZD0icyI+PHN0b3Agc3RvcC1jb2xvcj0iI2ZmZiIgc3RvcC1vcGFjaXR5PSIuNyIvPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iIzIyZDNlZSIgc3RvcC1vcGFjaXR5PSIuMSIvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMjAwIiBoZWlnaHQ9IjgwMCIgZmlsbD0iIzA5MDkwYiIvPjxlbGxpcHNlIGN4PSI2MDAiIGN5PSI0MjAiIHJ4PSI2MDAiIHJ5PSI1MDAiIGZpbGw9InVybCgjZykiIG9wYWNpdHk9Ii42Ii8+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSJ1cmwoI3MpIiBzdHJva2Utd2lkdGg9IjIiPjxlbGxpcHNlIGN4PSI2MDAiIGN5PSI0MTAiIHJ4PSI4MCIgcnk9IjcwIiB0cmFuc2Zvcm09InJvdGF0ZSgwIDYwMCA0MTApIi8+PGVsbGlwc2UgY3g9IjYwMCIgY3k9IjQxMCIgcng9IjEyNSIgcnk9IjkyIiB0cmFuc2Zvcm09InJvdGF0ZSg1IDYwMCA0MTApIi8+PGVsbGlwc2UgY3g9IjYwMCIgY3k9IjQxMCIgcng9IjE3MCIgcnk9IjExNCIgdHJhbnNmb3JtPSJyb3RhdGUoMTAgNjAwIDQxMCkiLz48ZWxsaXBzZSBjeD0iNjAwIiBjeT0iNDEwIiByeD0iMjE1IiByeT0iMTM2IiB0cmFuc2Zvcm09InJvdGF0ZSgxNSA2MDAgNDEwKSIvPjxlbGxpcHNlIGN4PSI2MDAiIGN5PSI0MTAiIHJ4PSIyNjAiIHJ5PSIxNTgiIHRyYW5zZm9ybT0icm90YXRlKDIwIDYwMCA0MTApIi8+PGVsbGlwc2UgY3g9IjYwMCIgY3k9IjQxMCIgcng9IjMwNSIgcnk9IjE4MCIgdHJhbnNmb3JtPSJyb3RhdGUoMjUgNjAwIDQxMCkiLz48ZWxsaXBzZSBjeD0iNjAwIiBjeT0iNDEwIiByeD0iMzUwIiByeT0iMjAyIiB0cmFuc2Zvcm09InJvdGF0ZSgzMCA2MDAgNDEwKSIvPjxlbGxpcHNlIGN4PSI2MDAiIGN5PSI0MTAiIHJ4PSIzOTUiIHJ5PSIyMjQiIHRyYW5zZm9ybT0icm90YXRlKDM1IDYwMCA0MTApIi8+PGVsbGlwc2UgY3g9IjYwMCIgY3k9IjQxMCIgcng9IjQ0MCIgcnk9IjI0NiIgdHJhbnNmb3JtPSJyb3RhdGUoNDAgNjAwIDQxMCkiLz48ZWxsaXBzZSBjeD0iNjAwIiBjeT0iNDEwIiByeD0iNDg1IiByeT0iMjY4IiB0cmFuc2Zvcm09InJvdGF0ZSg0NSA2MDAgNDEwKSIvPjxlbGxpcHNlIGN4PSI2MDAiIGN5PSI0MTAiIHJ4PSI1MzAiIHJ5PSIyOTAiIHRyYW5zZm9ybT0icm90YXRlKDUwIDYwMCA0MTApIi8+PGVsbGlwc2UgY3g9IjYwMCIgY3k9IjQxMCIgcng9IjU3NSIgcnk9IjMxMiIgdHJhbnNmb3JtPSJyb3RhdGUoNTUgNjAwIDQxMCkiLz48L2c+PC9zdmc+"
                                alt="hero background"
                                width={2268}
                                height={1740}
                                className="h-full w-full object-cover object-top"
                            />
                        </div>
                        <div className="relative z-10 mx-auto w-full max-w-5xl px-6">
                            <div
                                aria-hidden
                                className="perspective-near mask-radial-at-left mask-radial-from-65% mask-radial-to-90% mask-radial-[75%_100%] min-w-2xl mb-6 ml-auto max-w-3xl scale-90 py-12 pl-6 sm:mb-12 md:pl-12 lg:mb-20"
                            >
                                <div className="rotate-x-12 bg-muted rotate-y-2 rotate-z-10 relative flex h-56 -rotate-12 flex-col rounded-3xl border py-4 pl-4">
                                    <div className="bg-card ring-border shadow-foreground/10 bottom-15 absolute left-4 min-w-56 rounded-2xl p-1 shadow-xl ring-1 dark:shadow-black/25">
                                        <div className="hover:bg-muted flex cursor-pointer items-center gap-3 rounded-xl px-3 py-2 text-sm [&>svg]:size-4 [&>svg]:opacity-65">
                                            <Paperclip />
                                            <span>Add photos and files</span>
                                        </div>
                                        <span className="bg-size-[6px_1px] mx-3 my-0.5 block h-px bg-[linear-gradient(90deg,var(--color-foreground)_1px,transparent_1px)] bg-bottom bg-repeat-x opacity-30 dark:opacity-15" />
                                        <div className="hover:bg-muted flex cursor-pointer items-center gap-3 rounded-xl px-3 py-2 text-sm [&>svg]:size-4 [&>svg]:opacity-65">
                                            <ImageIcon />
                                            <span>Create image</span>
                                        </div>
                                        <div className="hover:bg-muted flex cursor-pointer items-center gap-3 rounded-xl px-3 py-2 text-sm [&>svg]:size-4 [&>svg]:opacity-65">
                                            <Lightbulb />
                                            <span>Thinking</span>
                                        </div>
                                        <div className="hover:bg-muted flex cursor-pointer items-center gap-3 rounded-xl px-3 py-2 text-sm [&>svg]:size-4 [&>svg]:opacity-65">
                                            <Telescope />
                                            <span>Deep research</span>
                                        </div>
                                        <div className="hover:bg-muted flex cursor-pointer items-center gap-3 rounded-xl px-3 py-2 text-sm [&>svg]:size-4 [&>svg]:opacity-65">
                                            <ShoppingBag />
                                            <span>Shopping research</span>
                                        </div>
                                        <div className="hover:bg-muted flex cursor-pointer items-center gap-3 rounded-xl px-3 py-2 text-sm [&>svg]:size-4 [&>svg]:opacity-65">
                                            <Github />
                                            <span>Open source access</span>
                                        </div>
                                    </div>

                                    <div className="bg-card ring-border shadow-foreground/6.5 dark:shadow-black/6.5 shadow-xs mt-auto flex h-fit justify-between gap-3 rounded-full p-2 ring-1">
                                        <div className="flex items-center gap-2">
                                            <div className="bg-muted flex size-9 cursor-pointer rounded-full *:m-auto *:size-4">
                                                <Plus />
                                            </div>
                                            <div className="text-muted-foreground text-sm">Ask anything...</div>
                                        </div>
                                        <div className="flex items-center gap-0.5">
                                            <div className="hover:bg-muted flex size-9 cursor-pointer rounded-full *:m-auto *:size-4">
                                                <Mic2 />
                                            </div>
                                            <div className="bg-foreground text-background flex size-9 cursor-pointer rounded-full *:m-auto *:size-4 hover:brightness-110">
                                                <AudioLines />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="mx-auto max-w-md text-center">
                                <h1 className="text-balance font-serif text-4xl font-medium sm:text-5xl">Ship faster. Integrate smarter.</h1>
                                <p className="text-muted-foreground mt-4 text-balance">Veil is your all-in-one engine for adding seamless integrations to your app.</p>

                                <Button
                                    asChild
                                    className="mt-6 pr-1.5"
                                >
                                    <Link href="#link">
                                        <span className="text-nowrap">Start Building</span>
                                        <ChevronRight className="opacity-50" />
                                    </Link>
                                </Button>
                            </div>
                        </div>
                    </div>
                </section>
            </main>
        </>
    )
}
