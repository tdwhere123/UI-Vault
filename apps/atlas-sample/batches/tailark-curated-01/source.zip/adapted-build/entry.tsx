import React from "react";import{createRoot}from"react-dom/client";import{ThemeProvider}from"next-themes";import"./runtime.css";
import C0 from "./registry/bases/radix/mist/blocks/features/four.tsx";
import C1 from "./registry/bases/radix/mist/blocks/features/ten.tsx";
import C2 from "./registry/bases/radix/veil/blocks/features/three.tsx";
import C3 from "./registry/bases/radix/veil/blocks/hero-section/four/hero-section.tsx";
const entries={"tailark:mist-features-four":C0,"tailark:mist-features-ten":C1,"tailark:veil-features-three":C2,"tailark:veil-hero-section-four-hero-section":C3};const r=document.getElementById("root");const C=entries[r.dataset.demo];createRoot(r).render(<ThemeProvider attribute="class" defaultTheme="light" enableSystem={false}><C/></ThemeProvider>);