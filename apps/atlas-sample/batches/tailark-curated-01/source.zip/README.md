# Tailark adapted preview
MIT original source revision 8139698115c1341bfd2e3e286c04bb4d8146f472.
Run npm ci then npx vite build inside adapted-build.
Remote photos/avatars replaced by original abstract SVG; stock video replaced by static gradient artwork. Business actions demo only.
