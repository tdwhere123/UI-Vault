带按钮输入
来源：https://github.com/creativetimofficial/tailwind-starter-kit/blob/ec4794270d089175077e1724df2b806d9f016b7c/components/input/input-with-button.html
许可：MIT（见LICENSE.txt）
original.* 为固定修订上的未改动原件或从文档摘出的原始示例标记。
preview.html 配合同目录 runtime.css 与 runtime.js 本地打开；无CDN。
交互范围：在带按钮的输入中填写（提交已拦截）
预览中的拦截脚本或内置库是本线加入的本地适配，不表示源交互已验证，也不表示后端业务成功。
未做真实浏览器视觉与交互验收，也没有真实运行页面封面。
