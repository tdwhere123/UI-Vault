import React from "react";import {createRoot} from "react-dom/client";import "./styles.css";
import { Scrub as C0 } from "./components/time-scrubber/Scrub.tsx";
const demos={"time-scrubber": C0};
const name=document.body.dataset.demo;const Demo=demos[name];if(!Demo)throw Error("Unknown demo: "+name);createRoot(document.getElementById("root")).render(<div className="demo-stage"><Demo/></div>);
