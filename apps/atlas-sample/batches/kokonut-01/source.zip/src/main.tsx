import React from "react";import {createRoot} from "react-dom/client";import "./styles.css";
import C0 from "./components/receipt-printer.tsx";
import C1 from "./components/page-flip.tsx";
import C2 from "./components/detent-dial.tsx";
import C3 from "./components/pull-cord.tsx";
import C4 from "./components/liquid-gauge.tsx";
import C5 from "./components/split-flap-text.tsx";
const demos={"receipt-printer": C0,"page-flip": C1,"detent-dial": C2,"pull-cord": C3,"liquid-gauge": C4,"split-flap-text": C5};
const name=document.body.dataset.demo;const Demo=demos[name];if(!Demo)throw Error("Unknown demo: "+name);createRoot(document.getElementById("root")).render(<div className="demo-stage"><Demo/></div>);
