import * as React from 'react';import {createRoot} from 'react-dom/client';import './styles.css';
import Demo0 from './demos/marquee';
import Demo1 from './demos/retro-grid';
import Demo2 from './demos/animated-list';
import Demo3 from './demos/particles';
import Demo4 from './demos/hyper-text';
import Demo5 from './demos/spinning-text';
const demos={'marquee':Demo0,'retro-grid':Demo1,'animated-list':Demo2,'particles':Demo3,'hyper-text':Demo4,'spinning-text':Demo5};const root=document.getElementById('root')!;const Demo=demos[root.dataset.demo as keyof typeof demos];createRoot(root).render(<div className={'stage stage-'+root.dataset.demo}><Demo/></div>);