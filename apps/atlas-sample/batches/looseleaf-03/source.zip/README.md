# Looseleaf looseleaf-03 - 6 original demos
Source revision 4bdb647940e2fefb3cebb394f3bad25c766a27d2, MIT.
originals/: unmodified upstream entry points and full internal source closure.
build/: adapted stage/CSS font subset and IIFE build entry; npm ci then npx vite build. No node_modules included.
preview/: independently served runtime and HTML, no CDN. CSS contains inline local fonts.
Build used existing installed dependencies matching the lockfile primary package versions. JS bundle and Vite CSS build passed. Browser visuals/interactions are NOT yet verified; final atlas QA must check each.
6 components only; imported primitives and variants do not add to counts. Fake demo data is not a real service, checkout, or user account.
