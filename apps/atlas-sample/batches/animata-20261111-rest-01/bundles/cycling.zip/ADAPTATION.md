
Complete esbuild+Tailwind recipe is included. Package entry is src/entry.tsx, which mounts the official Storybook Primary from src/animata/widget/cycling.stories.tsx (component src/animata/widget/cycling.tsx). Official internals, CSS and modules required by that entry are included as source, not only the compiled runtime. next/image shim resolves window.__atlasAssets including query suffixes.
