# AI Elements local Agent demos

Apache-2.0 upstream by Vercel. Original copyright header preserved in LICENSE; full Apache2 terms in APACHE-2.0.txt. No upstream NOTICE file was found.

Original components and official examples: originals/. Adapted local examples: src/demos/. Adapter shell, no external AI calls or destructive actions. This is a component teaching preview, not an actual assistant execution. The workflow labels are synthetic status summaries, not private model reasoning.

Changes: local state added to approval/plan/checkpoint demonstrations; external pictures replaced by local SVG; theme/system fonts local; source components untouched. Each item behavior explains interaction.

Build: Node24, npm ci, npm run build. Production IIFE and local CSS. Exact direct package versions and lockfile included; npm is needed for source rebuild, no node_modules bundled. Prebuilt preview/ works without npm/network.

Build proof does not imply browser QA; verify each item behavior in metadata.
