引用说明块（tailblocks:content-d）
来源：Tailblocks @ 34943e63da6a2d45a55a076ea18312a1c1098957
原件：React/JSX 区块。预览已转为静态 HTML 并拦截链接/表单，不表示源交互或后端已验收。
