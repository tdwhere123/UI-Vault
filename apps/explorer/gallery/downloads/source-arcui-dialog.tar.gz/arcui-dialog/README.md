# Arc dialog — source snapshot

Identity: arcui:dialog
Upstream: https://github.com/kuratlielia/arc-library
Registry: https://uiarc.dev/r/dialog.json
Fixed registry response SHA256: f00866fd51357914989f15ea43062acfb262537db02e29d5cc66895c2be48a7d

Original source bytes and the original MIT notice are retained. Copyright (c) 2026 Elia Kuratli. Keep LICENSE with copies. Source is fixed by saved registry response hash, not by a metadata Git revision.

Closure: partial. Runtime: not_tested. Restore: not_tested. No preview is supplied. Third-party npm/host dependencies and media are not bundled or fully audited. This is not a runnable application. No scripts from this archive have been run.

Unbundled requirements (includes literal relative-import locations; no relocation is implied):
- @radix-ui/react-dialog
- lib/motion-tokens.ts
- lucide-react
- motion/react
- react
- registry/components/lib/motion-tokens
- registry/foundation.css
- registry/motion-tokens.ts

See SOURCE.json for every literal module edge and external requirement. Shared foundation/motion files are not included. A support file saved under another path does not satisfy a literal relative import.
