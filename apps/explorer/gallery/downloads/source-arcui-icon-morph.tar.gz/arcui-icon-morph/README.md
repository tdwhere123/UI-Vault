# Arc icon-morph — source snapshot

Identity: arcui:icon-morph
Upstream: https://github.com/kuratlielia/arc-library
Registry: https://uiarc.dev/r/icon-morph.json
Fixed registry response SHA256: 024a7c334af81b0364441dbb9b673f6f6598a91985ef0ecb289d7ae0da2dc4ce

Original source bytes and the original MIT notice are retained. Copyright (c) 2026 Elia Kuratli. Keep LICENSE with copies. Source is fixed by saved registry response hash, not by a metadata Git revision.

Closure: partial. Runtime: not_tested. Restore: not_tested. No preview is supplied. Third-party npm/host dependencies and media are not bundled or fully audited. This is not a runnable application. No scripts from this archive have been run.

Unbundled requirements (includes literal relative-import locations; no relocation is implied):
- lib/motion-tokens.ts
- motion/react
- react
- registry/components/lib/motion-tokens
- registry/foundation.css
- registry/motion-tokens.ts

See SOURCE.json for every literal module edge and external requirement. Shared foundation/motion files are not included. A support file saved under another path does not satisfy a literal relative import.

Embedded glyph geometry: Copy/Bell/Heart and the other point/path shapes are part of this original source file, not merely external npm imports. Their independent origin/full third-party rights audit is not established by retained local evidence. No separate notice requirement was established; this is not a guarantee that no third-party rights exist. Original Arc MIT is retained.
