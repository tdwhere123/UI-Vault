# ToolGroup — source selection

Upstream: https://github.com/21st-dev/agent-elements
Fixed ref: `b04b36cb6381a1dd1a0e86cc7c90564ddcd56d37`
Direct entry: `lib/agent-ui/components/tools/tool-group.tsx`. No aggregate export is included.

Original source, shared CSS and MIT LICENSE are retained byte-for-byte. Copyright (c) 2026 21st.dev.
SOURCE.json lists original file hashes, origins, static module edges and external dependencies.
Closure: partial. Runtime / installation / rendering / restore: not_tested. This is not an installable package.
React JSX and Tailwind host configuration are required. Import the direct entry and integrate shared CSS yourself.
External packages, peer/transitive dependencies, runtime assets and third-party notices are not bundled or audited.
The upstream MIT license does not establish rights to omitted assets or dependencies. No preview is included.
