# Arc activity-heatmap — source snapshot

Identity: arcui:activity-heatmap
Upstream: https://github.com/kuratlielia/arc-library
Registry: https://uiarc.dev/r/activity-heatmap.json
Fixed registry response SHA256: dbba257f5b337cb9ec7081e0cc6240b93ccb1e1438c09552f1c450df5435f499

Original source bytes and the original MIT notice are retained. Copyright (c) 2026 Elia Kuratli. Keep LICENSE with copies. Source is fixed by saved registry response hash, not by a metadata Git revision.

Closure: partial. Runtime: not_tested. Restore: not_tested. No preview is supplied. Third-party npm/host dependencies and media are not bundled or fully audited. This is not a runnable application. No scripts from this archive have been run.

Unbundled requirements (derived from syntax; no relocation is implied):
- lib/motion-tokens.ts
- motion/react
- react
- registry/components/lib/motion-tokens
- registry/foundation.css
- registry/motion-tokens.ts

See SOURCE.json for every literal module edge and external requirement. Shared foundation/motion files are not included. A support file saved under another path does not satisfy a literal relative import.

Dependency syntax includes type/runtime/side-effect imports, re-exports, import=, import types and literal dynamic imports. Expression-based imports and unestablished require bindings are explicit unknown, not empty. Parse failures block admission. SOURCE.json is the dependency authority; its type and runtime requirements are conservatively combined.
