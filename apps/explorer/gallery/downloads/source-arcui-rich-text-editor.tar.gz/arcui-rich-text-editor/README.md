# Arc rich-text-editor — source snapshot

Identity: arcui:rich-text-editor
Upstream: https://github.com/kuratlielia/arc-library
Registry: https://uiarc.dev/r/rich-text-editor.json
Fixed registry response SHA256: 1371e45b3dfe94d47077609e411b9dd001d2be5aa17adbc8b603f237c7fd9918

Original source bytes and the original MIT notice are retained. Copyright (c) 2026 Elia Kuratli. Keep LICENSE with copies. Source is fixed by saved registry response hash, not by a metadata Git revision.

Closure: partial. Runtime: not_tested. Restore: not_tested. No preview is supplied. Third-party npm/host dependencies and media are not bundled or fully audited. This is not a runnable application. No scripts from this archive have been run.

Unbundled requirements (includes literal relative-import locations; no relocation is implied):
- lib/motion-tokens.ts
- lucide-react
- motion/react
- react
- registry/components/lib/motion-tokens
- registry/foundation.css
- registry/motion-tokens.ts

See SOURCE.json for every literal module edge and external requirement. Shared foundation/motion files are not included. A support file saved under another path does not satisfy a literal relative import.
