import React from "react";import{createRoot}from"react-dom/client";import"./styles.css";
import C0 from "./demos/drawer/responsive-header.tsx";
import C1 from "./demos/footers/animated-logo-footer.tsx";

import C3 from "./demos/card/product-card4.tsx";
import C4 from "./demos/color-picker/raws-color-picker.tsx";
const demos={"drawer-responsive-header":C0,"footers-animated-logo-footer":C1,"card-product-card4":C3,"color-picker-raws-color-picker":C4};const Demo=demos[document.body.dataset.demo];createRoot(document.getElementById("root")).render(<div className="demo-stage"><Demo/></div>);