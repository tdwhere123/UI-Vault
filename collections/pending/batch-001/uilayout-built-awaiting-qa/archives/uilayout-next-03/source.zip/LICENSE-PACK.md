This source package’s root LICENSE file is the UI Layouts MIT license
(Copyright (c) 2024 UI LAYOUT). That file alone does not license the
whole bundle or its runtime dependencies.

THIRD_PARTY_NOTICES.txt contains the applicable third-party license
texts recovered from the official npm tarball of each locked version
used by this batch’s selected demos and their package-lock closure.
The SPDX expression for the redistributable preview runtime of this
batch is recorded below and in the atlas catalog. It is not “MIT only”.

The originals/ directory is unchanged historical upstream source and
may still mention remote photographs or paths that the adapted demos
do not ship. Do not treat those references as packaged media rights.

The published tarball of react-remove-scroll-bar@2.3.8 (used in the
next-02 and next-03 lock closures) contains no LICENSE file, and no
matching 2.3.8 git tag was found. Its package.json asserts MIT; the
full text for that exact version remains Unknown and is not invented here.

A clean `npm ci && npm run build` from this zip was verified to exit 0.
The current atlas production runtime.js may include later bounded
patches and is not claimed to be a byte-for-byte rebuild of this zip.

Compound assertion: MIT; ISC; Apache-2.0; 0BSD (including lucide-react 1.70.0 and class-variance-authority 0.7.1).
