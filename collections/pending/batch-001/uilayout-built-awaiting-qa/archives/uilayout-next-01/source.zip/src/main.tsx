import React from "react";import{createRoot}from"react-dom/client";import"./styles.css";
import C0 from "./demos/drag/drag-items.tsx";
import C1 from "./demos/swapy/swapy-handle.tsx";

import C3 from "./demos/scroll-animation/sticky-hero-scroll.tsx";
import C4 from "./demos/scroll-animation/repeat-scroll.tsx";
const demos={"drag-drag-items":C0,"swapy-swapy-handle":C1,"scroll-animation-sticky-hero-scroll":C3,"scroll-animation-repeat-scroll":C4};const Demo=demos[document.body.dataset.demo];createRoot(document.getElementById("root")).render(<div className="demo-stage"><Demo/></div>);