'use client';
import { Heart } from 'lucide-react';
import { motion } from 'motion/react';
import Image from '@/image-shim';
import React, { useState } from 'react';

function Card2() {
  const [isActive, setIsActive] = useState(false);

  const handleClick = () => {
    setIsActive((prevState) => !prevState);
  };

  return (
    <div className='w-[350px] mx-auto '>
      <div className='dark:bg-white bg-neutral-50 border dark:border-none  rounded-2xl'>
        <div className='w-full h-56 relative'>
          <motion.button
            className='absolute top-2 right-3 z-20 text-2xl text-white'
            onClick={handleClick}
            animate={{ scale: isActive ? 1.2 : 1 }}
            transition={{ type: 'spring', stiffness: 1000, damping: 10 }}
          >
            {isActive ? (
              <>
                <Heart className=' fill-white' />
              </>
            ) : (
              <>
                <Heart />
              </>
            )}
          </motion.button>
          <Image
            src={
              "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28193%2C30%25%2C84%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28193%2C45%25%2C60%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28193%2C25%25%2C40%25%29%22/%3E%3C/svg%3E"
            }
            alt='shoes'
            width={1000}
            height={1000}
            className={`h-56 w-full rounded-2xl object-cover `}
          />
        </div>
        <article className='text-foreground space-y-2 p-2 pb-3'>
          <div className='flex justify-between'>
            <h1 className='font-semibold text-xl text-primary-dark'>Nike Air Max</h1>
            <span className='font-medium text-xl text-primary-dark'>$394</span>
          </div>
          <p className='text-xs  text-foreground'>Lorem ipsum, dolor sit amet consectetur adipisicing</p>

          <button className='w-full hover:text-white flex justify-center items-center gap-2 border-black border-2 text-black hover:bg-linear-to-r dark:from-[#070e41] dark:to-[#263381] from-[#3e5068] to-[#0c1970] py-2  rounded-md'>
            Add to cart
          </button>
        </article>
      </div>
    </div>
  );
}

export default Card2;

