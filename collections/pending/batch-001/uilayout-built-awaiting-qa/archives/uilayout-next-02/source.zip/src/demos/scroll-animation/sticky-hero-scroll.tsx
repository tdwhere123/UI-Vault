// @ts-nocheck
'use client';

import { motion, useScroll, useTransform } from 'motion/react';
import { useEffect, useRef } from 'react';

export default function StickyHeroScroll() {
  const container = useRef(undefined);
  const { scrollYProgress } = useScroll({
    target: container,
    offset: ['start start', 'end end'],
  });

  return (
    <>
      <main ref={container} className='relative h-[200vh] bg-black  '>
        <Section1 scrollYProgress={scrollYProgress} />
        <Section2 scrollYProgress={scrollYProgress} />
        <footer className='group bg-[#06060e] '>
          <h1 className='text-[16vw] translate-y-20 leading-[100%] uppercase font-semibold text-center bg-linear-to-r from-neutral-400 to-neutral-800 bg-clip-text text-transparent transition-all ease-linear'>
            ui-layout
          </h1>
          <div className='bg-black text-white h-40 relative z-10 grid place-content-center text-2xl rounded-tr-full rounded-tl-full'></div>
        </footer>
      </main>
    </>
  );
}

const Section1 = ({ scrollYProgress }) => {
  const scale = useTransform(scrollYProgress, [0, 1], [1, 0.8]);
  const rotate = useTransform(scrollYProgress, [0, 1], [0, -5]);
  return (
    <motion.section
      style={{ scale, rotate }}
      className='sticky  font-semibold top-0 h-screen bg-linear-to-t to-[#dadada] from-[#ebebeb] flex flex-col items-center justify-center text-black'
    >
      <div className='absolute bottom-0 left-0 right-0 top-0 bg-[linear-gradient(to_right,#4f4f4f2e_1px,transparent_1px),linear-gradient(to_bottom,#4f4f4f2e_1px,transparent_1px)] bg-size-[54px_54px] mask-[radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]'></div>

      <h1 className='2xl:text-7xl text-6xl px-8 font-semibold text-center tracking-tight leading-[120%]'>
        An Hero section Animation <br /> Scroll Please 👇
      </h1>
    </motion.section>
  );
};

const Section2 = ({ scrollYProgress }) => {
  const scale = useTransform(scrollYProgress, [0, 1], [0.8, 1]);
  const rotate = useTransform(scrollYProgress, [0, 1], [5, 0]);

  return (
    <motion.section
      style={{ scale, rotate }}
      className='relative h-screen bg-linear-to-t to-[#1a1919] from-[#06060e] text-white '
    >
      <div className='absolute bottom-0 left-0 right-0 top-0 bg-[linear-gradient(to_right,#4f4f4f2e_1px,transparent_1px),linear-gradient(to_bottom,#4f4f4f2e_1px,transparent_1px)] bg-size-[54px_54px] mask-[radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]'></div>
      <article className='container mx-auto relative z-10 '>
        <h1 className='text-6xl leading-[100%] py-10 font-semibold  tracking-tight '>
          Images That doesn't Make any sense <br /> but still in this section
        </h1>
        <div className='grid grid-cols-4 gap-4'>
          <img
            src="data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%2813%2C30%25%2C84%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%2813%2C45%25%2C60%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%2813%2C25%25%2C40%25%29%22/%3E%3C/svg%3E"
            alt='img'
            className=' object-cover w-full rounded-md h-full'
          />
          <img
            src="data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28133%2C30%25%2C84%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28133%2C45%25%2C60%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28133%2C25%25%2C40%25%29%22/%3E%3C/svg%3E"
            alt='img'
            className=' object-cover w-full rounded-md'
          />
          <img
            src="data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%2837%2C30%25%2C84%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%2837%2C45%25%2C60%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%2837%2C25%25%2C40%25%29%22/%3E%3C/svg%3E"
            alt='img'
            className=' object-cover w-full rounded-md h-full'
          />
          <img
            src="data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28188%2C30%25%2C84%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28188%2C45%25%2C60%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28188%2C25%25%2C40%25%29%22/%3E%3C/svg%3E"
            alt='img'
            className=' object-cover w-full rounded-md h-full'
          />
        </div>
      </article>
    </motion.section>
  );
};

