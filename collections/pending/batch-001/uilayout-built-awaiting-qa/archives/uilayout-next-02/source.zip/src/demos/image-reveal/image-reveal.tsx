'use client';

import { motion, useSpring } from 'motion/react';
import React, { type MouseEvent, useRef, useState } from 'react';

interface ImageItem {
  img: string;
  label: string;
  tag: string;
}

function ImageReveal2() {
  const [img, setImg] = useState<{ src: string; alt: string; opacity: number }>({
    src: '',
    alt: '',
    opacity: 0,
  });

  const imageRef = useRef<HTMLImageElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const list: ImageItem[] = [
    {
      img: "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%2866%2C30%25%2C84%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%2866%2C45%25%2C60%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%2866%2C25%25%2C40%25%29%22/%3E%3C/svg%3E",
      label: 'Stay Confident',
      tag: 'Style',
    },
    {
      img: "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28156%2C30%25%2C84%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28156%2C45%25%2C60%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28156%2C25%25%2C40%25%29%22/%3E%3C/svg%3E",
      label: 'Create Your Space',
      tag: 'Design',
    },
    {
      img: "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28122%2C30%25%2C84%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28122%2C45%25%2C60%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28122%2C25%25%2C40%25%29%22/%3E%3C/svg%3E",
      label: 'Be Yourself',
      tag: 'Identity',
    },
    {
      img: "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%2864%2C30%25%2C84%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%2864%2C45%25%2C60%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%2864%2C25%25%2C40%25%29%22/%3E%3C/svg%3E",
      label: 'Live Inspired',
      tag: 'Lifestyle',
    },
  ];

  const spring = {
    stiffness: 150,
    damping: 15,
    mass: 0.1,
  };

  const imagePos = {
    x: useSpring(0, spring),
    y: useSpring(0, spring),
  };

  const handleMove = (e: MouseEvent<HTMLDivElement>) => {
    if (!imageRef.current || !containerRef.current) return;

    const containerRect = containerRef.current.getBoundingClientRect();
    const { clientX, clientY } = e;
    const relativeX = clientX - containerRect.left;
    const relativeY = clientY - containerRect.top;

    imagePos.x.set(relativeX - imageRef.current.offsetWidth / 2);
    imagePos.y.set(relativeY - imageRef.current.offsetHeight / 2);
  };

  const handleImageInteraction = (item: ImageItem, opacity: number) => {
    setImg({ src: item.img, alt: item.label, opacity });
  };

  return (
    <section ref={containerRef} onMouseMove={handleMove} className='relative w-4/5 mx-auto p-4'>
      {list.map((item) => (
        <div
          key={item.label}
          onMouseEnter={() => handleImageInteraction(item, 1)}
          onMouseMove={() => handleImageInteraction(item, 1)}
          onMouseLeave={() => handleImageInteraction(item, 0)}
          className='w-full py-5 cursor-pointer text-center flex justify-between items-center text-primary border-b border-border last:border-none'
        >
          <p className='text-5xl'>{item.label}</p>
          <span>
            {item.tag} <span className='w-3 h-3 bg-primary inline-block'></span>
          </span>
        </div>
      ))}

      <motion.img
        ref={imageRef}
        src={img.src}
        alt={img.alt}
        className='w-[300px] h-[220px] rounded-lg object-cover absolute top-0 left-0 transition-opacity duration-200 ease-in-out pointer-events-none'
        style={{
          x: imagePos.x,
          y: imagePos.y,
          opacity: img.opacity,
        }}
      />
    </section>
  );
}

export default ImageReveal2;

