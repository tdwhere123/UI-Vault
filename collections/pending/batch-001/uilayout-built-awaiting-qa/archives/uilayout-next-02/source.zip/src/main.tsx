import React from "react";import{createRoot}from"react-dom/client";import"./styles.css";
import C0 from "./demos/timeline-animation/index.tsx";
import C1 from "./demos/mac/genie-effect.tsx";
import C2 from "./demos/linear-modal/standalone-version.tsx";
import C3 from "./demos/image-reveal/image-reveal.tsx";
import C4 from "./demos/drawer/nested-vaul-drawer.tsx";
const demos={"timeline-animation-index":C0,"mac-genie-effect":C1,"linear-modal-standalone-version":C2,"image-reveal-image-reveal":C3,"drawer-nested-vaul-drawer":C4};const Demo=demos[document.body.dataset.demo];createRoot(document.getElementById("root")).render(<div className="demo-stage"><Demo/></div>);