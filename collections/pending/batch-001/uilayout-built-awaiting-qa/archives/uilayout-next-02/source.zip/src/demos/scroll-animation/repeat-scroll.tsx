'use client';
import { ScrollAnimation } from '@/components/ui/scroll-animation';
import React from 'react';

function RepeatScroll() {
  return (
    <section>
      <div className='h-[500px] grid place-content-center'>
        <h1 className='text-6xl font-semibold text-center py-8'>Scroll Down 👇 </h1>
      </div>
      <div className='py-2'>
        <div className=' columns-3'>
          <ScrollAnimation direction='left' viewport={{ amount: 0.5, margin: '0px 0px 0px 0px' }}>
            <img
              src="data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28163%2C30%25%2C84%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28163%2C45%25%2C60%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28163%2C25%25%2C40%25%29%22/%3E%3C/svg%3E"
              alt=''
              className='w-full mb-2'
            />
          </ScrollAnimation>
          <ScrollAnimation direction='left' viewport={{ amount: 0.5, margin: '0px 0px 0px 0px' }}>
            <img
              src="data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%2832%2C30%25%2C84%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%2832%2C45%25%2C60%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%2832%2C25%25%2C40%25%29%22/%3E%3C/svg%3E"
              alt=''
              className='w-full mb-2'
            />
          </ScrollAnimation>
          <ScrollAnimation direction='left' viewport={{ amount: 0.5, margin: '0px 0px 0px 0px' }}>
            <img
              src="data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28140%2C30%25%2C84%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28140%2C45%25%2C60%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28140%2C25%25%2C40%25%29%22/%3E%3C/svg%3E"
              alt=''
              className='w-full mb-2'
            />
          </ScrollAnimation>

          <ScrollAnimation viewport={{ amount: 0.5, margin: '0px 0px 0px 0px' }}>
            <img
              src="data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%2896%2C30%25%2C84%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%2896%2C45%25%2C60%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%2896%2C25%25%2C40%25%29%22/%3E%3C/svg%3E"
              alt=''
              className='w-full mb-2'
            />
          </ScrollAnimation>
          <ScrollAnimation viewport={{ amount: 0.5, margin: '0px 0px 0px 0px' }}>
            <img
              src="data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%2893%2C30%25%2C84%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%2893%2C45%25%2C60%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%2893%2C25%25%2C40%25%29%22/%3E%3C/svg%3E"
              alt=''
              className='w-full mb-2'
            />
          </ScrollAnimation>
          <ScrollAnimation viewport={{ amount: 0.5, margin: '0px 0px 0px 0px' }}>
            <img
              src="data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28120%2C30%25%2C84%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28120%2C45%25%2C60%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28120%2C25%25%2C40%25%29%22/%3E%3C/svg%3E"
              alt=''
              className='w-full mb-2'
            />
          </ScrollAnimation>
          <ScrollAnimation direction='right' viewport={{ amount: 0.5, margin: '0px 0px 0px 0px' }}>
            <img
              src="data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%2893%2C30%25%2C84%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%2893%2C45%25%2C60%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%2893%2C25%25%2C40%25%29%22/%3E%3C/svg%3E"
              alt=''
              className='w-full mb-2'
            />
          </ScrollAnimation>
          <ScrollAnimation direction='right' viewport={{ amount: 0.5, margin: '0px 0px 0px 0px' }}>
            <img
              src="data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28120%2C30%25%2C84%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28120%2C45%25%2C60%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28120%2C25%25%2C40%25%29%22/%3E%3C/svg%3E"
              alt=''
              className='w-full mb-2'
            />
          </ScrollAnimation>
          <ScrollAnimation direction='right' viewport={{ amount: 0.5, margin: '0px 0px 0px 0px' }}>
            <img
              src="data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%2893%2C30%25%2C84%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%2893%2C45%25%2C60%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%2893%2C25%25%2C40%25%29%22/%3E%3C/svg%3E"
              alt=''
              className='w-full mb-2'
            />
          </ScrollAnimation>
          <ScrollAnimation direction='right' viewport={{ amount: 0.5, margin: '0px 0px 0px 0px' }}>
            <img
              src="data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28120%2C30%25%2C84%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28120%2C45%25%2C60%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28120%2C25%25%2C40%25%29%22/%3E%3C/svg%3E"
              alt=''
              className='w-full mb-2'
            />
          </ScrollAnimation>
        </div>
      </div>
    </section>
  );
}

export default RepeatScroll;

