Original UI Layouts MIT source preserved under originals. Preview uses official default demo export. Replace third-party photographs with locally authored SVG landscapes, Next Image/Link with thin browser equivalents. Original animation logic preserved. Runtime is a standalone React IIFE; no backend or real payments.
Build: npm ci && npm run build. Generated dist/runtime.js and CSS are served by preview HTML.

Offline closure repair: remote Noto fire GIF replaced with a plain text decorative star (not the original artwork). Cruip-credited hover card and gist-credited horizontal scroll excluded pending secondary licensing. Unselected adapted demos omitted; original selected demo files remain unchanged.
