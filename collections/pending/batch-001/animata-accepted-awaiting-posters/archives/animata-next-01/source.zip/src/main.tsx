import React from "react";import{createRoot}from"react-dom/client";import"./styles.css";
import * as S0 from "./animata/carousel/expandable.stories.tsx";
import * as S1 from "./animata/carousel/image-carousel.stories.tsx";
import * as S2 from "./animata/container/fibonacci-lines.stories.tsx";
import * as S3 from "./animata/container/sibling-focus-nav.stories.tsx";
import * as S4 from "./animata/hero/product-features.stories.tsx";
const demos={"expandable":S0,"image-carousel":S1,"fibonacci-lines":S2,"sibling-focus-nav":S3,"product-features":S4};const story=demos[document.body.dataset.demo];const meta=story.default;const primary=story.Primary;const args={...meta.args,...primary.args};const Demo=primary.render||meta.render||meta.component;createRoot(document.getElementById("root")).render(<div className="demo-stage"><Demo {...args}/></div>);