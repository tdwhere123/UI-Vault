import React from "react";import{createRoot}from"react-dom/client";import"./styles.css";
import * as S0 from "./animata/list/transition-list.stories.tsx";
import * as S1 from "./animata/overlay/modal.stories.tsx";
import * as S2 from "./animata/scroll/aperture-reveal.stories.tsx";
import * as S3 from "./animata/scroll/stacked-sections.stories.tsx";
import * as S4 from "./animata/section/pricing.stories.tsx";
const demos={"transition-list":S0,"modal":S1,"aperture-reveal":S2,"stacked-sections":S3,"pricing":S4};const story=demos[document.body.dataset.demo];const meta=story.default;const primary=story.Primary;const args={...meta.args,...primary.args};const Demo=primary.render||meta.render||meta.component;createRoot(document.getElementById("root")).render(<div className="demo-stage"><Demo {...args}/></div>);