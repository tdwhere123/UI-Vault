import type { Meta, StoryObj } from "@storybook/react";
import ImageCarousel from "@/animata/carousel/image-carousel";

const meta = {
  title: "Carousel/Image Carousel",
  component: ImageCarousel,
  parameters: {
    layout: "centered",
  },
  tags: ["autodocs"],
  argTypes: {},
} satisfies Meta<typeof ImageCarousel>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Primary: Story = {
  args: {
    items: [
      {
        id: 1,
        title: "Item 1",
        image:
          "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28139%2C35%25%2C85%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28139%2C50%25%2C65%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28139%2C30%25%2C42%25%29%22/%3E%3C/svg%3E",
      },
      {
        id: 2,
        title: "Item 2",
        image:
          "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28306%2C35%25%2C85%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28306%2C50%25%2C65%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28306%2C30%25%2C42%25%29%22/%3E%3C/svg%3E",
      },
      {
        id: 3,
        title: "Item 3",
        image:
          "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28164%2C35%25%2C85%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28164%2C50%25%2C65%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28164%2C30%25%2C42%25%29%22/%3E%3C/svg%3E",
      },
      {
        id: 4,
        title: "Item 4",
        image:
          "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28272%2C35%25%2C85%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28272%2C50%25%2C65%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28272%2C30%25%2C42%25%29%22/%3E%3C/svg%3E",
      },
      {
        id: 5,
        title: "Item 4",
        image:
          "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28272%2C35%25%2C85%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28272%2C50%25%2C65%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28272%2C30%25%2C42%25%29%22/%3E%3C/svg%3E",
      },
    ],
  },
};

