import type { Meta, StoryObj } from "@storybook/react";
import DiscloseImage from "@/animata/image/disclose-image";

const meta = {
  title: "Image/Disclose Image",
  component: DiscloseImage,
  parameters: {
    layout: "centered",
  },
  tags: ["autodocs"],
  argTypes: {},
} satisfies Meta<typeof DiscloseImage>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Primary: Story = {
  args: {
    src: "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28253%2C35%25%2C85%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28253%2C50%25%2C65%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28253%2C30%25%2C42%25%29%22/%3E%3C/svg%3E",
    alt: "A beautiful image",
    doorClassName: "bg-yellow-200",
    vertical: false,
  },
};

