import type { Meta, StoryObj } from "@storybook/react";
import { PlusCircle } from "lucide-react";

import Marquee from "@/animata/container/marquee";
import FlippingCards, { getFlippingCardsAccent } from "@/animata/list/flipping-cards";

const demoItems = [
  {
    font: "Antonov AN-255",
    title: "Aa",
    image:
      "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28291%2C35%25%2C85%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28291%2C50%25%2C65%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28291%2C30%25%2C42%25%29%22/%3E%3C/svg%3E",
  },
  {
    font: "Boeing 747",
    title: "Bb",
    image:
      "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28325%2C35%25%2C85%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28325%2C50%25%2C65%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28325%2C30%25%2C42%25%29%22/%3E%3C/svg%3E",
  },
  {
    font: "Cessna 172",
    title: "Cc",
    image:
      "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28284%2C35%25%2C85%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28284%2C50%25%2C65%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28284%2C30%25%2C42%25%29%22/%3E%3C/svg%3E",
  },
  {
    font: "Dassault Falcon 7X",
    title: "Dd",
    image:
      "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28291%2C35%25%2C85%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28291%2C50%25%2C65%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28291%2C30%25%2C42%25%29%22/%3E%3C/svg%3E",
  },
  {
    font: "Embraer EMB 120 ",
    title: "Ee",
    image:
      "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28291%2C35%25%2C85%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28291%2C50%25%2C65%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28291%2C30%25%2C42%25%29%22/%3E%3C/svg%3E",
  },
  {
    font: "Fokker F100",
    title: "Ff",
    image:
      "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221000%22%20height%3D%22800%22%20viewBox%3D%220%200%201000%20800%22%3E%3Crect%20width%3D%221000%22%20height%3D%22800%22%20fill%3D%22hsl%28223%2C35%25%2C85%25%29%22/%3E%3Ccircle%20cx%3D%22740%22%20cy%3D%22180%22%20r%3D%2290%22%20fill%3D%22hsl%28223%2C50%25%2C65%25%29%22/%3E%3Cpath%20d%3D%22M0%20800V580L250%20180L600%20700L800%20360L1000%20650V800Z%22%20fill%3D%22hsl%28223%2C30%25%2C42%25%29%22/%3E%3C/svg%3E",
  },
];

const meta = {
  title: "List/Flipping Cards",
  component: FlippingCards,
  parameters: {
    layout: "centered",
  },
  tags: ["autodocs"],
} satisfies Meta<typeof FlippingCards>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Primary: Story = {
  render: () => (
    <FlippingCards>
      {demoItems.map((item, index) => (
        <FlippingCards.Item key={item.title}>
          <FlippingCards.Item.Front className="flex bg-background">
            <div className="flex w-full flex-col border border-border px-3 py-4 text-sm text-foreground">
              <span className="border-t-2 border-foreground pt-1">{item.font}</span>
              <span className="mt-4 border-b-2 border-foreground px-1 font-serif text-8xl">
                {item.title}
              </span>
              <div className="mt-12 flex items-center justify-between">
                <span>{index + 1}</span>
                <PlusCircle size={18} />
              </div>
            </div>
          </FlippingCards.Item.Front>
          <FlippingCards.Item.Back
            className="flex flex-col justify-between overflow-hidden py-4 text-sm"
            style={{ backgroundColor: getFlippingCardsAccent(index) }}
          >
            <img alt="" src={item.image} className="size-32 px-2" />
            <Marquee className="font-serif text-5xl text-white" applyMask={false}>
              {item.font.split(" ")[0]}
            </Marquee>
            <div className="flex items-center justify-between px-3">
              <span className="text-black">See more</span>
              <PlusCircle size={18} color="black" />
            </div>
          </FlippingCards.Item.Back>
        </FlippingCards.Item>
      ))}
    </FlippingCards>
  ),
};

