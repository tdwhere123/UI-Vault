import React from "react";import{createRoot}from"react-dom/client";import"./styles.css";
import * as S0 from "./animata/image/trailing-image.stories.tsx";
import * as S1 from "./animata/list/flipping-cards.stories.tsx";
import * as S2 from "./animata/list/orbiting-items-3-d.stories.tsx";
import * as S3 from "./animata/list/reveal-image.stories.tsx";
import * as S4 from "./animata/list/transaction-list.stories.tsx";
const demos={"trailing-image":S0,"flipping-cards":S1,"orbiting-items-3-d":S2,"reveal-image":S3,"transaction-list":S4};const story=demos[document.body.dataset.demo];const meta=story.default;const primary=story.Primary;const args={...meta.args,...primary.args};const Demo=primary.render||meta.render||meta.component;createRoot(document.getElementById("root")).render(<div className="demo-stage"><Demo {...args}/></div>);